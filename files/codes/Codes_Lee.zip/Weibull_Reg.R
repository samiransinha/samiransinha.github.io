### We need SurvRegCensCov library to obtain initial values for the Weibull regression
library(SurvRegCensCov)
### We need statmod library for numerical integration using Gaussian quadrature
library(statmod)

### E1684 Data from the webgage "http://merlot.stat.uconn.edu/~mhchen/survbook/"
### Y is the vector for the observed time, D is the vector of the censoring status(1 for observed, 0 for censored)
### X is the vector of covariate
Y <- c(1.57808,1.48219,7.33425,2.23288,9.38356,3.27671,9.64384,1.66575,0.94247,1.68767,2.34247,0.89863,9.03288,
		9.63014,0.52603,1.82192,0.93425,8.9863,3.35068,8.67397,0.41096,2.7863,2.56438,8.75342,0.56986,8.4,7.25205,
		4.3863,8.36712,8.99178,0.86575,4.76986,1.15616,7.28767,3.13151,8.55068,8.45753,4.59452,2.88219,0.89589,
		1.76164,7.8137,8.33425,2.62192,0.16164,8.24658,1.52603,5.30959,0.87123,0.41644,4.2411,0.13699,7.07671,
		0.13151,8.0274,6.16164,1.29863,1.29041,7.99726,8.34795,7.30137,2.32877,0.56438,5.6274,1.23014,7.94521,
		5.06301,3.27671,0.60822,0.65753,0.8411,8.4,0.18356,2.62466,7.96438,7.77808,0.22192,2.33973,0.52329,8.0411,
		7.83288,0.6411,0.38356,7.82192,0.51781,8.09863,8.16712,4.4274,0.88493,2.78356,2.64658,8.2137,7.41918,0.99726,
		5.88493,0.41644,3.53699,7.56164,7.53151,0.27671,0.76986,7.62192,7.79726,0.6411,1.14521,2.01644,2.84384,7,
		1.27397,7.09589,2.0411,0.83562,0.92329,0.07397,7.30685,2.07671,7.70959,6.1589,6.89315,3.30685,0.36164,1.97808,
		1.23836,0.10685,7.63836,2.06301,7.42466,0.50959,0.65753,6.93151,7.23288,6.01096,0.33699,6.47123,0.94795,2.91781,
		1.59726,0.84932,1.38356,3.81644,7.06849,7.0411,1.00274,6.34795,1.18082,0.97534,2.16712,6.85479,1.38356,1.71507,
		0.79452,6.86301,6.50411,0.42466,0.9863,6.13699,3.8,6.48493,6.96438,6.78082,0.56164,2.67123,1.56712,2.07397,
		0.33973,3.37808,3.15068,6.81096,3.20822,0.6274,1.64384,1.40822,6.06575,1.66301,1.36986,5.46849,0.4274,1.13973,
		1.73699,5.54521,0.85205,0.43014,1.20822,4.36164,0.52877,6.51507,2.89863,6.20274,1.21644,6,6.25479,6.49863,1.13699,
		1.69589,6.41096,6.02192,3.04932,5.6274,0.72603,0.73425,1.47945,0.37808,5.7589,1.48219,5.88493,1.80274,1.40548,
		4.74795,5.24658,0.29041,5.83836,5.32055,5.16712,5.59178,5.77808,0.53425,2.22466,3.59726,5.32329,1.7863,0.70411,
		4.94795,5.45479,4.32877,1.16164,5.20274,4.40822,1.41096,4.92877,5.42192,0.98904,0.36438,4.38082,0.7726,4.90959,
		1.26849,0.58082,4.95616,5.12329,4.74795,4.90685,1.41918,0.4411,4.29863,4.63836,4.8137,4.50137,3.92329,4.86027,
		0.52603,2.10685,4.24384,3.39178,4.36164,4.81918)
D <- c(1,1,0,1,0,1,0,1,1,1,1,1,0,0,1,1,1,0,1,1,1,1,1,0,1,0,0,1,0,0,1,0,1,0,1,0,0,1,1,1,1,0,0,1,1,0,1,1,1,1,1,1,1,1,0,
		0,1,1,0,0,0,1,1,1,1,0,1,1,0,1,1,0,1,1,0,0,1,1,1,0,0,1,1,0,1,0,0,1,1,1,1,0,0,1,1,1,1,0,0,1,1,0,0,1,1,1,1,0,1,0,
		1,1,1,1,0,1,0,0,0,1,1,1,1,1,0,1,0,1,1,0,0,1,1,0,1,1,1,1,1,1,0,0,1,0,1,1,1,0,1,1,1,0,0,1,1,0,1,0,0,0,1,1,1,1,1,
		1,1,0,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,1,1,0,1,0,1,0,0,0,1,1,0,0,1,0,1,1,1,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,1,0,1,
		1,0,0,1,1,0,0,1,0,0,1,1,0,1,1,1,1,0,0,0,0,1,1,0,0,0,1,1,0,1,1,0,1,0,0)
X <- c(2,2,1,1,2,1,1,2,1,2,2,1,2,2,1,2,1,2,1,1,2,1,1,2,2,1,1,2,2,2,2,1,2,1,1,2,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,2,1,2,2,
		2,1,1,2,2,1,2,1,1,1,2,2,1,2,2,1,2,2,1,1,1,1,2,1,1,1,2,2,2,2,1,1,1,2,2,2,1,2,1,1,1,1,1,2,2,1,1,2,1,1,2,2,1,1,1,1,1,2,
		2,2,1,2,1,1,2,2,1,1,1,2,1,1,1,2,1,1,2,1,2,2,2,1,2,1,2,2,2,1,1,1,1,1,2,2,2,1,2,1,2,2,1,2,2,2,1,2,2,1,2,1,2,2,1,1,1,1,
		2,2,1,1,2,2,2,1,1,2,1,2,1,2,2,2,2,1,1,2,1,2,1,2,2,1,2,2,2,2,2,1,1,2,1,1,1,1,2,2,2,1,2,1,1,1,2,2,2,2,1,2,2,1,1,2,2,1,
		1,1,2,2,1,2,1,1,1,2,1,1,2,2,1,2,2,2,1,2,1,1,2,2)
n <- length(Y)

### Prior parameters
a0 <- 1 # shape parameter of the prior distribution of alpha
k0 <- 0.001 # rate parameter of the prior distribution of alpha
sig0 <- sqrt(10^4) # variance of the prior distribution of beta

### Loading Fortran subroutine into R
dyn.load("std_cal_Fortran.so")

### MCMC parameters 
M <- 10000 # the number of final MCMC samples
burn <- 5000 # the number of burn-in samples
B <- 500 # the number of bootstrap replications

### Standard error calculation based on the full bootstrap approach
FBmeans <- matrix(0, B, 3)
FBquants <- matrix(0, B, 9)
FBexts <- matrix(0, B, 6)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	ini.tmp.boot <- WeibullReg(Surv(Y[idx], D[idx]) ~ X[idx])$coef
	ini.boot <- c(ini.tmp.boot[2,1], log(ini.tmp.boot[1,1]), ini.tmp.boot[3,1]) ## alpha, beta0, beta1
	isd <- runif(1, 1, 90000)
	Full.boot <- .Fortran("MCMCWeibull", Y = as.double(Y[idx]), D = as.double(D[idx]), X = as.double(X[idx]),
				a0 = as.double(a0), k0 = as.double(k0), sig0 = as.double(sig0), M = as.integer(M), 
				burn = as.integer(burn), n = as.integer(n), var_p = as.double(0.25^2), ini = as.double(ini.boot),
				isd = as.integer(isd), Post_alpha = as.double(rep(0, M + burn)), Post_beta0 = as.double(rep(0, M + burn)),
				Post_beta1 = as.double(rep(0, M + burn)))
	FBmeans[i,] <- c(mean(Full.boot$Post_alpha[-(1:burn)]), 
					mean(Full.boot$Post_beta0[-(1:burn)]), mean(Full.boot$Post_beta1[-(1:burn)]))
	FBquants[i,] <- c(quantile(Full.boot$Post_alpha[-(1:burn)], probs = c(0.25, 0.5, 0.75)),
						quantile(Full.boot$Post_beta0[-(1:burn)], probs = c(0.25, 0.5, 0.75)),
						quantile(Full.boot$Post_beta1[-(1:burn)], probs = c(0.25, 0.5, 0.75)))
	FBexts[i,] <- c(quantile(Full.boot$Post_alpha[-(1:burn)], probs = c(0.025, 0.975)),
						quantile(Full.boot$Post_beta0[-(1:burn)], probs = c(0.025, 0.975)),
						quantile(Full.boot$Post_beta1[-(1:burn)], probs = c(0.025, 0.975)))
}

### Drawing MCMC sample from the original dataset for the reference of following steps
ini.tmp <- WeibullReg(Surv(Y, D) ~ X)$coef
ini <- c(ini.tmp[2,1], log(ini.tmp[1,1]), ini.tmp[3,1]) ## alpha, beta0, beta1
isd <- runif(1, 1, 90000)
Post.para <- .Fortran("MCMCWeibull", Y = as.double(Y), D = as.double(D), X = as.double(X),
			a0 = as.double(a0), k0 = as.double(k0), sig0 = as.double(sig0), M = as.integer(M), 
			burn = as.integer(burn), n = as.integer(n), var_p = as.double(0.25^2), ini = as.double(ini.boot),
			isd = as.integer(isd), Post_alpha = as.double(rep(0, M + burn)), Post_beta0 = as.double(rep(0, M + burn)),
			Post_beta1 = as.double(rep(0, M + burn)))

### Saving the posterior samples for the importance sampling technique after discarding "burn" number of burn-in samples
Post.alpha = Post.para$Post_alpha[-(1:burn)]
Post.beta0 = Post.para$Post_beta0[-(1:burn)]
Post.beta1 = Post.para$Post_beta1[-(1:burn)]


### Calculation for the standard error of the posterior mean based on the importance sampling approach
ISmeans <- matrix(0, B, 3)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	tab <- table(factor(idx, levels = 1:n))
	IS <- .Fortran("ISWeibull", Y = as.double(Y), D = as.double(D), X = as.double(X), tab = as.double(tab),
				a0 = as.double(a0), k0 = as.double(k0), sig0 = as.double(sig0), M = as.integer(M), 
				n = as.integer(n), Post_alpha = as.double(Post.alpha), Post_beta0 = as.double(Post.beta0),
				Post_beta1 = as.double(Post.beta1), omega = as.double(rep(0, M)))

	wt <- IS$omega/sum(IS$omega)

	ISmeans[i,] <- c(sum(Post.alpha*wt), sum(Post.beta0*wt), sum(Post.beta1*wt))
}

### Calculation for the standard error of the posterior quantiles (Q1, Q2, and Q3) 
### based on the importance sampling approach
probs <- c(0.25, 0.5, 0.75)
ISquants <- matrix(0, B, 9)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	tab <- table(factor(idx, levels = 1:n))
	ISqtl <-.Fortran("ISweibullQtl", Y = as.double(Y), D = as.double(D), X = as.double(X), tab = as.double(tab),
		M = as.integer(M), n = as.integer(n), Post_alpha = as.double(Post.alpha), Post_beta0 = as.double(Post.beta0), 
		Post_beta1 = as.double(Post.beta1), probs = as.double(probs), nprobs = as.integer(length(probs)), 
		qtl_alpha = as.double(rep(0, length(probs))), qtl_beta0 = as.double(rep(0, length(probs))), 
		qtl_beta1 = as.double(rep(0, length(probs))))
	ISquants[i,] <- c(ISqtl$qtl_alpha, ISqtl$qtl_beta0, ISqtl$qtl_beta1)
}

### Calculation for the standard error of the posterior extreme quantiles (2.5% and 97.5%)
### based on the importance sampling approach
idx <- sample(size = n, 1:n, replace = TRUE)
tab <- table(factor(idx, levels = 1:n))

### Posterior quantities
iqr_a <- IQR(Post.alpha)
max_a <- max(Post.alpha)
min_a <- min(Post.alpha)

iqr_b0 <- IQR(Post.beta0)
max_b0 <- max(Post.beta0)
min_b0 <- min(Post.beta0)

iqr_b1 <- IQR(Post.beta1)
max_b1 <- max(Post.beta1)
min_b1 <- min(Post.beta1)

### Candidates for alpha and beta, we will use these candidates for all bootstrap dataset
min_cand_a <- mean(Post.alpha) - 6*sd(Post.alpha)
max_cand_a <- mean(Post.alpha) + 6*sd(Post.alpha)
cand_a <- runif(M, min = min_cand_a, max = max_cand_a)

min_cand_b0 <- mean(Post.beta0) - 6*sd(Post.beta0)
max_cand_b0 <- mean(Post.beta0) + 6*sd(Post.beta0)
cand_b0 <- runif(M, min = min_cand_b0, max = max_cand_b0)

min_cand_b1 <- mean(Post.beta1) - 6*sd(Post.beta1)
max_cand_b1 <- mean(Post.beta1) + 6*sd(Post.beta1)
cand_b1 <- runif(M, min = min_cand_b1, max = max_cand_b1)

### Parameters for Gaussian quadrature
nGL <- 32
eps_a <- 0.1*iqr_a
eps_b0 <- 0.1*iqr_b0
eps_b1 <- 0.1*iqr_b1
GL1 <- gauss.quad(n = nGL, "legendre")

### Computing the importance weight for the reference bootstrap sample based on equaion (3) in Section 4.1.
reference <- .Fortran("ISweibullQtlextrm", Y = as.double(Y), D = as.double(D), X = as.double(X), tab = as.double(tab),
		a0 = as.double(a0), k0 = as.double(k0), sig0 = as.double(sig0), M = as.integer(M), n = as.integer(n),
		Post_alpha = as.double(Post.alpha), Post_beta0 = as.double(Post.beta0), Post_beta1 = as.double(Post.beta1),
		nGL = as.integer(nGL), GLw = as.double(GL1$weights),
		GLx_a = as.double((max_a - min_a + 2*0.1*iqr_a)*GL1$nodes/2 + (max_a + min_a)/2), 
		GLx_b0 = as.double((max_b0 - min_b0 + 2*0.1*iqr_b0)*GL1$nodes/2 + (max_b0 + min_b0)/2),
		GLx_b1 = as.double((max_b1 - min_b1 + 2*0.1*iqr_b1)*GL1$nodes/2 + (max_b1 + min_b1)/2),
		min_a = as.double(min_a), max_a = as.double(max_a), eps_a = as.double(0.1*iqr_a),
		min_cand_a = as.double(min_cand_a), max_cand_a = as.double(max_cand_a), cand_a = as.double(cand_a), 
		min_b0 = as.double(min_b0), max_b0 = as.double(max_b0), eps_b0 = as.double(0.1*iqr_b0), 
		min_cand_b0 = as.double(min_cand_b0), max_cand_b0 = as.double(max_cand_b0), cand_b0 = as.double(cand_b0), 
		min_b1 = as.double(min_b1), max_b1 = as.double(max_b1), eps_b1 = as.double(0.1*iqr_b1), 
		min_cand_b1 = as.double(min_cand_b1), max_cand_b1 = as.double(max_cand_b1), cand_b1 = as.double(cand_b1), 
		omega_a = as.double(rep(0, M)), omega_b0 = as.double(rep(0, M)), omega_b1 = as.double(rep(0, M)))

Fhat_a <- cumsum(reference$omega_a[order(cand_a)])/sum(reference$omega_a)
Fhat_b0 <- cumsum(reference$omega_b0[order(cand_b0)])/sum(reference$omega_b0)
Fhat_b1 <- cumsum(reference$omega_b1[order(cand_b1)])/sum(reference$omega_b1)

### Creating object for saving extreme quantiles of each bootstrap replicate
ISexts <- matrix(0, B, 6)

ISexts[1,] <- c(cand_a[order(cand_a)][min(which(Fhat_a >= 0.025))], 
			cand_a[order(cand_a)][min(which(Fhat_a >= 0.975))],
			cand_b0[order(cand_b0)][min(which(Fhat_b0 >= 0.025))], 
			cand_b0[order(cand_b0)][min(which(Fhat_b0 >= 0.975))],
			cand_b1[order(cand_b1)][min(which(Fhat_b1 >= 0.025))], 
			cand_b1[order(cand_b1)][min(which(Fhat_b1 >= 0.975))])

### Evaluating the importance weight for the rest of the bootstrap sample based on equation (4) in Section 4.1.
for(i in 2:B){
	idx.b <- sample(size = n, 1:n, replace = TRUE)
	tab.b <- table(factor(idx.b, levels = 1:n))
	new <- .Fortran("WeiWTCoefCal", Y = as.double(Y), D = as.double(D), X = as.double(X), tab = as.double(tab), 
			tab_b = as.double(tab.b), M = as.integer(M), n = as.integer(n), Post_alpha = as.double(Post.alpha), 
			Post_beta0 = as.double(Post.beta0), Post_beta1 = as.double(Post.beta1), cand_a = as.double(cand_a), 
			cand_b0 = as.double(cand_b0), cand_b1 = as.double(cand_b1), omega_ref_a = as.double(reference$omega_a), 
			omega_ref_b0 = as.double(reference$omega_b0), omega_ref_b1 = as.double(reference$omega_b1), 
			omega_new_a = as.double(rep(0, M)), omega_new_b0 = as.double(rep(0, M)), 
			omega_new_b1 = as.double(rep(0, M)))

	Fhat_a <- cumsum(new$omega_new_a[order(cand_a)])/sum(new$omega_new_a)
	Fhat_b0 <- cumsum(new$omega_new_b0[order(cand_b0)])/sum(new$omega_new_b0)
	Fhat_b1 <- cumsum(new$omega_new_b1[order(cand_b1)])/sum(new$omega_new_b1)
	ISexts[i,] <- c(cand_a[order(cand_a)][min(which(Fhat_a >= 0.025))], 
				cand_a[order(cand_a)][min(which(Fhat_a >= 0.975))],
				cand_b0[order(cand_b0)][min(which(Fhat_b0 >= 0.025))], 
				cand_b0[order(cand_b0)][min(which(Fhat_b0 >= 0.975))],
				cand_b1[order(cand_b1)][min(which(Fhat_b1 >= 0.025))], 
				cand_b1[order(cand_b1)][min(which(Fhat_b1 >= 0.975))])
}

### Computing standard error of each posterior summaries
apply(FBmeans, 2, sd)
apply(ISmeans, 2, sd)
apply(FBquants, 2, sd)
apply(ISquants, 2, sd)
apply(FBexts, 2, sd)
apply(ISexts, 2, sd)


