### We need statmod library for numerical integration using Gaussian quadrature
library(statmod)

### Data Generation step in Section 5.1, alpha = -2.5, beta = 1
n <- 500
X <- rnorm(n)
Y <- rbinom(n, size = 1, prob = 1/(1+exp(2.5 - X)))

### Prior parameters
a <- 0 # mean of the prior distribution of alpha
b <- 0 # mean of the prior distribution of beta
sigma2 <- 2 # variance of the prior distribution of alpha
tau2 <- 2 # variance of the prior distribution of alpha

### Loading Fortran subroutine into R
dyn.load("std_cal_Fortran.so")

### MCMC parameters 
M <- 10000 # the number of final MCMC samples
burn <- 5000 # the number of burn-in samples
B <- 500 # the number of bootstrap replications

### Standard error calculation based on the full bootstrap approach
FBmeans <- matrix(0, B, 2)
FBquants <- matrix(0, B, 6)
FBexts <- matrix(0, B, 4)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	ini <- coef(glm(Y[idx] ~ X[idx], family = binomial(link = "logit")))
	isd <- runif(1, 1, 90000)
	Full.boot <- .Fortran("MCMClogit", Y = as.double(Y[idx]), X = as.double(X[idx]), n = as.integer(n), M = as.integer(M),
			burn = as.integer(burn), a = as.double(a), b = as.double(b), sigma2 = as.double(sigma2), 
			tau2 = as.double(tau2), var_pa = as.double(0.3^2), var_pa = as.double(0.3^2), ini = as.double(ini),
			Post_alpha = as.double(rep(0, M+burn)), Post_beta = as.double(rep(0, M+burn)), isd = as.integer(isd))
	FBmeans[i,] <- c(mean(Full.boot$Post_alpha[-(1:burn)]), mean(Full.boot$Post_beta[-(1:burn)]))
	FBquants[i,] <- c(quantile(Full.boot$Post_alpha[-(1:burn)], probs = c(0.25, 0.5, 0.75)),
						quantile(Full.boot$Post_beta[-(1:burn)], probs = c(0.25, 0.5, 0.75)))
	FBexts[i,] <- c(quantile(Full.boot$Post_alpha[-(1:burn)], probs = c(0.025, 0.975)),
						quantile(Full.boot$Post_beta[-(1:burn)], probs = c(0.025, 0.975)))
}

### Drawing MCMC sample from the original dataset for the reference of following steps
ini <- coef(glm(Y ~ X, family = binomial(link = "logit")))
isd <- runif(1, 1, 90000)
Post.para <- .Fortran("MCMClogit", Y = as.double(Y), X = as.double(X), n = as.integer(n), M = as.integer(M),
		burn = as.integer(burn), a = as.double(a), b = as.double(b), sigma2 = as.double(sigma2), 
		tau2 = as.double(tau2), var_pa = as.double(0.3^2), var_pa = as.double(0.3^2), ini = as.double(ini),
		Post_alpha = as.double(rep(0, M+burn)), Post_beta = as.double(rep(0, M+burn)), isd = as.integer(isd))
### Saving the posterior samples for the importance sampling technique after discarding "burn" number of burn-in samples
Post.alpha = Post.para$Post_alpha[-(1:burn)]
Post.beta = Post.para$Post_beta[-(1:burn)]


### Calculation for the standard error of the posterior mean based on the importance sampling approach
ISmeans <- matrix(0, B, 2)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	tab <- table(factor(idx, levels = 1:n))
	IS <- .Fortran("ISlogit", Y = as.double(Y), X = as.double(X), tab = as.double(tab),
				M = as.integer(M), n = as.integer(n), Post_alpha = as.double(Post.alpha), 
				Post_beta = as.double(Post.beta), omega = as.double(rep(0, M)))
	wt <- IS$omega/sum(IS$omega)
	ISmeans[i,] <- c(sum(Post.alpha*wt), sum(Post.beta*wt))
}

### Calculation for the standard error of the posterior quantiles (Q1, Q2, and Q3) 
### based on the importance sampling approach
probs <- c(0.25, 0.5, 0.75)
ISquants <- matrix(0, B, 6)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	tab <- table(factor(idx, levels = 1:n))
	ISqtl <- .Fortran("ISlogitQtl", Y = as.double(Y), X = as.double(X), tab = as.double(tab),
				M = as.integer(M), n = as.integer(n), Post_alpha = as.double(Post.alpha), 
				Post_beta = as.double(Post.beta), probs = as.double(probs), nprobs = as.integer(length(probs)),
				qtl_alpha = as.double(rep(0, length(probs))), qtl_beta = as.double(rep(0, length(probs))))
	ISquants[i,] <- c(ISqtl$qtl_alpha, ISqtl$qtl_beta)
}

### Calculation for the standard error of the posterior extreme quantiles (2.5% and 97.5%)
### based on the importance sampling approach
idx <- sample(size = n, 1:n, replace = TRUE)
tab <- table(factor(idx, levels = 1:n))

### Posterior quantities
iqr_a <- IQR(Post.alpha)
max_a <- max(Post.alpha)
min_a <- min(Post.alpha)

iqr_b <- IQR(Post.beta)
max_b <- max(Post.beta)
min_b <- min(Post.beta)

### Candidates for alpha and beta, we will use these candidates for all bootstrap dataset
min_cand_a <- mean(Post.alpha) - 6*sd(Post.alpha)
max_cand_a <- mean(Post.alpha) + 6*sd(Post.alpha)
cand_a <- runif(M, min = min_cand_a, max = max_cand_a)

min_cand_b <- mean(Post.beta) - 6*sd(Post.beta)
max_cand_b <- mean(Post.beta) + 6*sd(Post.beta)
cand_b <- runif(M, min = min_cand_b, max = max_cand_b)

### Parameters for Gaussian quadrature
nGL <- 32
eps_a <- 0.1*iqr_a
eps_b <- 0.1*iqr_b
GL1 <- gauss.quad(n = nGL, "legendre")


### Computing the importance weight for the reference bootstrap sample based on equaion (3) in Section 4.1.
reference <- .Fortran("ISlogitQtlextrm", Y = as.double(Y), X = as.double(X), tab = as.double(tab), 
	a = as.double(a), b = as.double(b), sigma2 = as.double(sigma2), tau2 = as.double(tau2), 
	n = as.integer(n), Post_alpha = as.double(Post.alpha), Post_beta = as.double(Post.beta), M = as.integer(M),
	min_a = as.double(min_a), max_a = as.double(max_a), min_b = as.double(min_b), max_b = as.double(max_b), 
	nGL = as.integer(nGL), GLw = as.double(GL1$weights),
	GLx_a = as.double((max_a - min_a + 2*0.1*iqr_a)*GL1$nodes/2 + (max_a + min_a)/2), eps_a = as.double(0.1*iqr_a), 
	GLx_b = as.double((max_b - min_b + 2*0.1*iqr_b)*GL1$nodes/2 + (max_b + min_b)/2), eps_b = as.double(0.1*iqr_b), 
	min_cand_a = as.double(min_cand_a), max_cand_a = as.double(max_cand_a), cand_a = as.double(cand_a), 
	min_cand_b = as.double(min_cand_b), max_cand_b = as.double(max_cand_b), cand_b = as.double(cand_b), 
	omega_a = as.double(rep(0, M)), omega_b = as.double(rep(0, M)))
	
Fhat_a <- cumsum(reference$omega_a[order(cand_a)])/sum(reference$omega_a)
Fhat_b <- cumsum(reference$omega_b[order(cand_b)])/sum(reference$omega_b)


### Creating object for saving extreme quantiles of each bootstrap replicate
ISexts <- matrix(0, B, 4)

ISexts[1,] <- c(cand_a[order(cand_a)][min(which(Fhat_a >= 0.025))], 
			cand_a[order(cand_a)][min(which(Fhat_a >= 0.975))],
			cand_b[order(cand_b)][min(which(Fhat_b >= 0.025))], 
			cand_b[order(cand_b)][min(which(Fhat_b >= 0.975))])

### Evaluating the importance weight for the rest of the bootstrap sample based on equation (4) in Section 4.1.
for(i in 2:B){
	idx.b <- sample(size = n, 1:n, replace = TRUE)
	tab.b <- table(factor(idx.b, levels = 1:n))  
	new <- .Fortran("logitWTCoefCal", Y = as.double(Y), X = as.double(X), 
				tab = as.double(tab), tab_b = as.double(tab.b), n = as.integer(n),
				Post_alpha = as.double(Post.alpha), Post_beta = as.double(Post.beta),
				cand_a = as.double(cand_a), cand_b = as.double(cand_b),
				omega_ref_a = as.double(reference$omega_a), omega_ref_b = as.double(reference$omega_b), 
				M = as.integer(M), omega_new_a = as.double(rep(0, M)), omega_new_b = as.double(rep(0, M)))
	Fhat_a <- cumsum(new$omega_new_a[order(cand_a)])/sum(new$omega_new_a)
	Fhat_b <- cumsum(new$omega_new_b[order(cand_b)])/sum(new$omega_new_b)
	ISexts[i,] <- c(cand_a[order(cand_a)][min(which(Fhat_a >= 0.025))], 
				cand_a[order(cand_a)][min(which(Fhat_a >= 0.975))],
				cand_b[order(cand_b)][min(which(Fhat_b >= 0.025))], 
				cand_b[order(cand_b)][min(which(Fhat_b >= 0.975))])
}

### Computing standard error of each posterior summaries
apply(FBmeans, 2, sd)
apply(ISmeans, 2, sd)
apply(FBquants, 2, sd)
apply(ISquants, 2, sd)
apply(FBexts, 2, sd)
apply(ISexts, 2, sd)


