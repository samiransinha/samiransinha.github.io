### We need statmod library for numerical integration using Gaussian quadrature
library(statmod)

### Data Generation step in Section 5.2, alpha = 0.23, beta = 0.47
n <- 1000
X <- rnorm(n, 0.5, 1) # Distribution of the true covariates, mu_x = 0.5, sig2_x = 1
U <- rnorm(n, 0, sqrt(0.5)) # Distribution of the measurement error, sig2_u = 0.5
W <- X + U
Y <- 0.23 + 0.47*X + rnorm(n, 0, sqrt(0.5)) # true alpha = 0.2, true beta = 0.8, sig2_e = 0.03^2

### Prior parameters
sig2_alp <- 10^4 # variance for prior distribution of alpha
sig2_bet <- 10^4 # variance for prior distribution of beta
sig2_mux <- 10^4 # variance for prior distribution of mu_x, mean of the distribution of X
del <- 1 # shape paramter for prior distribution of sig2_x, sig2_e
lam <- 1 # rate paramter for prior distribution of sig2_x, sig2_e
sig2_u <- 0.5 # Assumed to be known 

### Loading Fortran subroutine into R
dyn.load("std_cal_Fortran.so")

### MCMC parameters 
M <- 10000 # the number of final MCMC samples
burn <- 5000 # the number of burn-in samples
B <- 500 # the number of bootstrap replications

### Standard error calculation based on the full bootstrap approach
FBmeans <- matrix(0, B, 2)
FBquants <- matrix(0, B, 6)
FBexts <- matrix(0, B, 4)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	isd <- runif(1, 1, 90000)
	mux_ini_b <- mean(W[idx])
	lm_ini_b <- lm(Y[idx] ~ W[idx])
	alp_ini_b <- coef(lm_ini_b)[1]
	bet_ini_b <- (var(W[idx])/(var(W[idx])-sig2_u))*coef(lm_ini_b)[2]
	sig2e_ini_b <- var(Y[idx]-alp_ini_b-bet_ini_b*W[idx])
	sig2x_ini_b <- var(W[idx]) - sig2_u
	
	Full.boot <- .Fortran("MCMCMEM", Y = as.double(Y[idx]), W = as.double(W[idx]), M = as.integer(M), 
			n = as.integer(n), burn = as.integer(burn), sig2_alp = as.double(sig2_alp), 
			sig2_bet = as.double(sig2_bet), sig2_mux = as.double(sig2_mux), sig2_u = as.double(sig2_u), 
			del = as.double(del), lam = as.double(lam), X_ini = as.double(W[idx]), 
			alp_ini = as.double(alp_ini_b), bet_ini = as.double(bet_ini_b), mux_ini = as.double(mux_ini_b), 
			sig2e_ini = as.double(sig2e_ini_b), sig2x_ini = as.double(sig2x_ini_b),
			Post_alpha = as.double(rep(0, M+burn)), Post_beta = as.double(rep(0, M+burn)),
			Post_mux = as.double(rep(0, M+burn)), Post_sig2x = as.double(rep(0, M+burn)), 
			Post_sig2e = as.double(rep(0, M+burn)), Post_X = as.double(matrix(0, nrow = n, ncol = M+burn)), 
			isd = as.integer(isd))

	FBmeans[i,] <- c(mean(Full.boot$Post_alpha[-(1:burn)]), mean(Full.boot$Post_beta[-(1:burn)]))
	FBquants[i,] <- c(quantile(Full.boot$Post_alpha[-(1:burn)], probs = c(0.25, 0.5, 0.75)),
						quantile(Full.boot$Post_beta[-(1:burn)], probs = c(0.25, 0.5, 0.75)))
	FBexts[i,] <- c(quantile(Full.boot$Post_alpha[-(1:burn)], probs = c(0.025, 0.975)),
						quantile(Full.boot$Post_beta[-(1:burn)], probs = c(0.025, 0.975)))
}

### Drawing MCMC sample from the original dataset for the reference of following steps
mux_ini <- mean(W)
lm_ini <- lm(Y ~ W)
alp_ini <- coef(lm_ini)[1]
bet_ini <- (var(W)/(var(W)-sig2_u))*coef(lm_ini)[2]
sig2e_ini <- var(Y-alp_ini-bet_ini*W)
sig2x_ini <- var(W) - sig2_u

isd <- runif(1, 1, 90000)
Post.para <- .Fortran("MCMCMEM", Y = as.double(Y), W = as.double(W), M = as.integer(M), 
			n = as.integer(n), burn = as.integer(burn), sig2_alp = as.double(sig2_alp), 
			sig2_bet = as.double(sig2_bet), sig2_mux = as.double(sig2_mux), sig2_u = as.double(sig2_u), 
			del = as.double(del), lam = as.double(lam), X_ini = as.double(W), alp_ini = as.double(alp_ini), 
			bet_ini = as.double(bet_ini), mux_ini = as.double(mux_ini), sig2e_ini = as.double(sig2e_ini), 
			sig2x_ini = as.double(sig2x_ini), Post_alpha = as.double(rep(0, M+burn)), 
			Post_beta = as.double(rep(0, M+burn)), Post_mux = as.double(rep(0, M+burn)), 
			Post_sig2x = as.double(rep(0, M+burn)), Post_sig2e = as.double(rep(0, M+burn)), 
			Post_X = as.double(matrix(0, nrow = n, ncol = M+burn)), isd = as.integer(isd))

### Saving the posterior samples for the importance sampling technique after discarding "burn" number of burn-in samples
Post.alpha = Post.para$Post_alpha[-(1:burn)]
Post.beta = Post.para$Post_beta[-(1:burn)]
Post.mux = Post.para$Post_mux[-(1:burn)]
Post.sig2x = Post.para$Post_sig2x[-(1:burn)]
Post.sig2e = Post.para$Post_sig2x[-(1:burn)]
Post.X = Post.para$Post_X[-(1:(n*burn))]

### Calculation for the standard error of the posterior mean based on the importance sampling approach
ISmeans <- matrix(0, B, 2)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	tab <- table(factor(idx, levels = 1:n))
	IS <- .Fortran("ISMEM", Y = as.double(Y), W = as.double(W), M = as.integer(M), 
			n = as.integer(n), tab = as.double(tab), sig2_u = as.double(sig2_u), 
			Post_alpha = as.double(Post.alpha), Post_beta = as.double(Post.beta), 
			Post_mux = as.double(Post.mux), Post_sig2x = as.double(Post.sig2x), 
			Post_sig2e = as.double(Post.sig2e), Post_X = as.double(Post.X), omega = as.double(rep(0, M)))
	wt <- IS$omega/sum(IS$omega)
	ISmeans[i,] <- c(sum(Post.alpha*wt), sum(Post.beta*wt))
}

### Calculation for the standard error of the posterior quantiles (Q1, Q2, and Q3) 
### based on the importance sampling approach
probs <- c(0.25, 0.5, 0.75)
ISquants <- matrix(0, B, 6)
for(i in 1:B){
	idx <- sample(size = n, 1:n, replace = TRUE)
	tab <- table(factor(idx, levels = 1:n))
	ISqtl <- .Fortran("ISMEMQtl", Y = as.double(Y), W = as.double(W), M = as.integer(M), n = as.integer(n), 
			tab = as.double(tab), sig2_u = as.double(sig2_u), Post_alpha = as.double(Post.alpha), 
			Post_beta = as.double(Post.beta), Post_mux = as.double(Post.mux), Post_sig2x = as.double(Post.sig2x), 
			Post_sig2e = as.double(Post.sig2e), Post_X = as.double(Post.X), probs = as.double(probs), 
			nprobs = as.integer(length(probs)), qtl_alpha = as.double(rep(0, length(probs))), 
			qtl_beta = as.double(rep(0, length(probs))), qtl_mux = as.double(rep(0, length(probs))), 
			qtl_sig2x = as.double(rep(0, length(probs))), qtl_sig2e = as.double(rep(0, length(probs))))
	ISquants[i,] <- c(ISqtl$qtl_alpha, ISqtl$qtl_beta)
}

### Calculation for the standard error of the posterior extreme quantiles (2.5% and 97.5%)
### based on the importance sampling approach
idx <- sample(size = n, 1:n, replace = TRUE)
tab <- table(factor(idx, levels = 1:n))

### Posterior quantities
iqr_a <- IQR(Post.alpha)
max_a <- max(Post.alpha)
min_a <- min(Post.alpha)

iqr_b <- IQR(Post.beta)
max_b <- max(Post.beta)
min_b <- min(Post.beta)

### Candidates for alpha and beta, we will use these candidates for all bootstrap dataset
min_cand_a <- mean(Post.alpha) - 6*sd(Post.alpha)
max_cand_a <- mean(Post.alpha) + 6*sd(Post.alpha)
cand_a <- runif(M, min = min_cand_a, max = max_cand_a)

min_cand_b <- mean(Post.beta) - 6*sd(Post.beta)
max_cand_b <- mean(Post.beta) + 6*sd(Post.beta)
cand_b <- runif(M, min = min_cand_b, max = max_cand_b)

### Parameters for Gaussian quadrature
nGL <- 32
eps_a <- 0.1*iqr_a
eps_b <- 0.1*iqr_b
GL1 <- gauss.quad(n = nGL, "legendre")


### Computing the importance weight for the reference bootstrap sample based on equaion (3) in Section 4.1.
reference <- .Fortran("ISMEMQtlextrm", Y = as.double(Y), W = as.double(W), M = as.integer(M), n = as.integer(n), 
		tab = as.double(tab), sig2_u = as.double(sig2_u), Post_alpha = as.double(Post.alpha), 
		Post_beta = as.double(Post.beta), Post_mux = as.double(Post.mux), Post_sig2x = as.double(Post.sig2x), 
		Post_sig2e = as.double(Post.sig2e), Post_X = as.double(Post.X), sig2_alp = as.double(sig2_alp),
		sig2_bet = as.double(sig2_bet), nGL = as.integer(nGL), GLw = as.double(GL1$weights),
		GLx_a = as.double((max_a - min_a + 2*0.1*iqr_a)*GL1$nodes/2 + (max_a + min_a)/2), 
		GLx_b = as.double((max_b - min_b + 2*0.1*iqr_b)*GL1$nodes/2 + (max_b + min_b)/2),
		min_a = as.double(min_a), max_a = as.double(max_a), eps_a = as.double(0.1*iqr_a),
		min_cand_a = as.double(min_cand_a), max_cand_a = as.double(max_cand_a), cand_a = as.double(cand_a), 
		min_b = as.double(min_b), max_b = as.double(max_b), eps_b = as.double(0.1*iqr_b),
		min_cand_b = as.double(min_cand_b), max_cand_b = as.double(max_cand_b), cand_b = as.double(cand_b),
		omega_a = as.double(rep(0, M)), omega_b = as.double(rep(0, M)))
	
Fhat_a <- cumsum(reference$omega_a[order(cand_a)])/sum(reference$omega_a)
Fhat_b <- cumsum(reference$omega_b[order(cand_b)])/sum(reference$omega_b)


### Creating object for saving extreme quantiles of each bootstrap replicate
ISexts <- matrix(0, B, 4)

ISexts[1,] <- c(cand_a[order(cand_a)][min(which(Fhat_a >= 0.025))], 
			cand_a[order(cand_a)][min(which(Fhat_a >= 0.975))],
			cand_b[order(cand_b)][min(which(Fhat_b >= 0.025))], 
			cand_b[order(cand_b)][min(which(Fhat_b >= 0.975))])

### Evaluating the importance weight for the rest of the bootstrap sample based on equation (4) in Section 4.1.
for(i in 2:B){
	idx.b <- sample(size = n, 1:n, replace = TRUE)
	tab.b <- table(factor(idx.b, levels = 1:n))  
	new <- .Fortran("WTCoefCalMEM", Y = as.double(Y), W = as.double(W), M = as.integer(M), n = as.integer(n), 
			tab = as.double(tab), tab_b = as.double(tab.b), sig2_u = as.double(sig2_u), 
			Post_alpha = as.double(Post.alpha), Post_beta = as.double(Post.beta), Post_mux = as.double(Post.mux), 
			Post_sig2x = as.double(Post.sig2x), Post_sig2e = as.double(Post.sig2e), Post_X = as.double(Post.X), 
			cand_a = as.double(cand_a), cand_b = as.double(cand_b),
			omega_ref_a = as.double(reference$omega_a), omega_ref_b = as.double(reference$omega_b),
			omega_new_a = as.double(rep(0, M)), omega_new_b = as.double(rep(0, M)))

	Fhat_a <- cumsum(new$omega_new_a[order(cand_a)])/sum(new$omega_new_a)
	Fhat_b <- cumsum(new$omega_new_b[order(cand_b)])/sum(new$omega_new_b)
	ISexts[i,] <- c(cand_a[order(cand_a)][min(which(Fhat_a >= 0.025))], 
				cand_a[order(cand_a)][min(which(Fhat_a >= 0.975))],
				cand_b[order(cand_b)][min(which(Fhat_b >= 0.025))], 
				cand_b[order(cand_b)][min(which(Fhat_b >= 0.975))])
}

### Computing standard error of each posterior summaries
apply(FBmeans, 2, sd)
apply(ISmeans, 2, sd)
apply(FBquants, 2, sd)
apply(ISquants, 2, sd)
apply(FBexts, 2, sd)
apply(ISexts, 2, sd)


