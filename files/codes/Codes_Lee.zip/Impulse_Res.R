###############################################################################
### We didn't write a Fortran code here. Necessary functions are at the end of this file.

### We need MASS library to generate multivariate normal random variable
library(MASS)

### We need MCMCpack library to generate inverse wishart random variable
library(MCMCpack)

### Data Generation step in Section 5.4
n <- 1000
p <- 2 
B <- matrix(c(0.7, 0.2, 0.3, 0.6), p, p)
c.vec <- matrix(c(-0.7, 1.3), 1, p)
SIG <- matrix(c(1, 0.5, 0.5, 1), p, p)

errs <- mvrnorm(n+1, mu = rep(0, p), Sigma = SIG)
Ys <- matrix(0, nrow = n, ncol = p)
Ys[1,] <- c.vec + errs[1,]
for(i in 2:n) Ys[i,] <- c.vec + Ys[i-1,] %*% B + errs[i,]

### Prior parameters
L <- 2 # fitting VAR(L) model
phi0 <- rep(0, p*(1+L*p)) # mean of the prior distribution of phi
M0 <- diag(x = 20, p*(1+L*p)) # variance of the prior distribution of phi
M0inv <- diag(x = 1/20, p*(1+L*p)) # inverse of variance of the prior distribution of phi
b <- p+1 # parameter of the prior distribution of sigma

### MCMC parameters 
M <- 10000 # the number of final MCMC samples
burn <- 5000 # the number of burn-in samples
cnst <- 15 # Percentage of block length for MBB
B <- 5 # the number of bootstrap replications


### Standard error calculation based on the full bootstrap approach
Full.boot <- NULL
for(i in 1:B){
	Full.boot <- rbind(Full.boot, 
		IRF.boot(i, Y = Ys, upto = 15, cnst = cnst, M = M, burn = burn, L = L, phi0, M0inv, b))
}

### Drawing MCMC sample from the original dataset for the reference of following steps
MCMC.ori <- TS.MC(M = M, burn = burn, Y = Ys, L = L, upto = 15, phi0 = phi0, M0inv = M0inv, b = b)

### Calculation for the standard error of the posterior mean based on the importance sampling approach
IS <- NULL
for(i in 1:B){
	IS <- rbind(IS, 
		IS.IRF(i, Y = Ys, upto = 15, cnst = cnst, M = M, burn = burn, L = 2, MCMC.ori))
}

### Computing standard error of each posterior summaries
### The standard error of impulse response of y2 to a shock in y1
FB21 <- NULL
IS21 <- NULL
for(i in 1:B){
	FB21 <- rbind(FB21, Full.boot[((i-1)*15 + 1):(i*15),3])
	IS21 <- rbind(IS21, IS[((i-1)*15 + 1):(i*15),3])
}
apply(FB21, 2, sd)
apply(IS21, 2, sd)

### The standard error of impulse response of y1 to a shock in y2
FB12 <- NULL
IS12 <- NULL
for(i in 1:B){
	FB12 <- rbind(FB12, Full.boot[((i-1)*15 + 1):(i*15),4])
	IS12 <- rbind(IS12, IS[((i-1)*15 + 1):(i*15),4])
}
apply(FB12, 2, sd)
apply(IS12, 2, sd)


################################################################################################
### Source code for calcuations

TS.MC <- function(M, burn, Y, L, upto, phi0, M0inv, b){

	n <- nrow(Y)
	p <- ncol(Y)
	Xd <- matrix(1, nrow = n, ncol = 1)
	for(i in 1:L) Xd <- cbind(Xd, rbind(matrix(0, nrow = i, ncol = p), Y[-((n-i+1):n),]))
	XX <- t(Xd) %*% Xd
	Phihat <- solve(XX) %*% t(Xd) %*% Y
	phihat <- matrix(as.vector(Phihat), ncol = 1)
	SIGhat <- crossprod(Y - Xd %*% Phihat)/n

	SIGini <- SIGhat
	Post.phi <- matrix(0, nrow = M-burn, ncol = length(phihat))
	Post.SIG <- matrix(0, nrow = M-burn, ncol = p*p)
	Post.Z11 <- matrix(0, nrow = M-burn, ncol = upto)
	Post.Z21 <- matrix(0, nrow = M-burn, ncol = upto)
	Post.Z12 <- matrix(0, nrow = M-burn, ncol = upto)
	Post.Z22 <- matrix(0, nrow = M-burn, ncol = upto)
	for(i in 1:M){
		post.Vm <- solve(M0inv + solve(SIGini) %x% XX )
		post.mu <- phihat +  post.Vm %*% M0inv %*% (phi0 - phihat)

		phinew <- mvrnorm(1, mu = post.mu, Sigma = post.Vm)
		Phinew <- matrix(phinew, ncol = p)

		IW.S <- crossprod(Y - Xd %*% Phinew)
		IW.v <- n + b - p - 1

		SIGnew <- riwish(IW.v, IW.S)
		
		if(i > burn){
			Post.phi[i-burn,] <- phinew
			Post.SIG[i-burn,] <- as.vector(SIGnew)

			Psinew <- chol(SIGnew)
			Hs <-  recH(L, p, B = Phinew[-1,], j = upto)
			IRFnew <- NULL
			for(k in 1:upto) IRFnew <- rbind(IRFnew, as.vector(Psinew %*% Hs[[k]]))
			
			Post.Z11[i-burn,] <- IRFnew[,1]
			Post.Z21[i-burn,] <- IRFnew[,2]
			Post.Z12[i-burn,] <- IRFnew[,3]
			Post.Z22[i-burn,] <- IRFnew[,4]
			
		}
		SIGini <- SIGnew
	}
	return(list(Post.phi = Post.phi, Post.SIG = Post.SIG, Post.Z11 = Post.Z11,
				Post.Z21 = Post.Z21, Post.Z12 = Post.Z12, Post.Z22 = Post.Z22))
}

##########################################################################################
### Impulse response

recH <- function(L, p, B, j){
	Bs <- list(0)
	for(i in 1:L) Bs[[i]] <- B[((i-1)*p+1):(i*p),]
	re <- list(0)
	re[[1]] <- Bs[[1]]
	for(k in 1:L){
		re.tmp <- diag(0, p)
		for(l in 1:k){
			if((k-l) !=0) re.tmp <- re.tmp + Bs[[l]]%*%re[[k-l]] else re.tmp <- re.tmp + Bs[[l]]
		}
		re[[k]] <- re.tmp
	}
	for(k in (L+1):j){
		re.tmp <- diag(0,p)
		for(l in 1:L) re.tmp <- re.tmp + Bs[[l]]%*%re[[k-l]]
		re[[k]] <- re.tmp
	}
	return(re)
}

##########################################################################################
### Wrapper function of IRF for bootstrap dataset using Full Bootstrap
IRF.boot <- function(i, Y, upto, cnst, M, burn, L, phi0, M0inv, b){
	n <- nrow(Y)
	l <- round(cnst*n^(1/3))
	idx <- sample(1:(n-l+1), ceiling(n/l), replace = TRUE)
	Y.boot <- NULL
	for(j in idx) Y.boot <- rbind(Y.boot, Y[j:(j+l-1),])
	Y.boot <- Y.boot[1:n,]
	MCMC.boot <- TS.MC(M = M, burn = burn, Y = Y.boot, L = L, upto = upto, phi0 = phi0, M0inv = M0inv, b = b)

	re11 <- colMeans(MCMC.boot$Post.Z11)
	re21 <- colMeans(MCMC.boot$Post.Z21)
	re12 <- colMeans(MCMC.boot$Post.Z12)
	re22 <- colMeans(MCMC.boot$Post.Z22)	
	
	re <- cbind(re11, re21, re12, re22)
	colnames(re) <- c("Z11", "Z21", "Z12", "Z22")
	return(re)
}

##########################################################################################
### Wrapper function of IRF for bootstrap dataset using Importance sampling
IS.IRF <- function(i, Y, upto, cnst, M, burn, L, MCMC.ori){
	p <- ncol(Y)
	l <- round(cnst*n^(1/3))
	idx <- sample(1:(n-l+1), ceiling(n/l), replace = TRUE)
	Y.boot <- NULL
	for(j in idx) Y.boot <- rbind(Y.boot, Y[j:(j+l-1),])
	Y.boot <- Y.boot[1:n,]

	Xd <- Xd.boot <- matrix(1, nrow = n, ncol = 1)
	for(j in 1:L){
		Xd <- cbind(Xd, rbind(matrix(0, nrow = j, ncol = p), Y[-((n-j+1):n),]))
		Xd.boot <- cbind(Xd.boot, rbind(matrix(0, nrow = j, ncol = p), Y.boot[-((n-j+1):n),]))
	}

	wt <- 0
	for(j in 1:(M-burn)){
		#if(!(j%%100)) cat(j)
		#if(!(j%%1000)) cat('\n')
		PHI.j <- matrix(MCMC.ori$Post.phi[j,], ncol = p)
		iSIG.j <- solve(matrix(MCMC.ori$Post.SIG[j,], ncol = p))
		
		num1 <- sum(diag(iSIG.j %*% crossprod(Y.boot - Xd.boot %*% PHI.j)))
		num2 <- sum(diag(iSIG.j %*% crossprod(Y - Xd %*% PHI.j)))

		wt[j] <- exp(-0.5*num1 + 0.5*num2)
	}
	wt <- wt/sum(wt)
	re11 <- colSums(MCMC.ori$Post.Z11 * wt)
	re21 <- colSums(MCMC.ori$Post.Z21 * wt)
	re12 <- colSums(MCMC.ori$Post.Z12 * wt)
	re22 <- colSums(MCMC.ori$Post.Z22 * wt)
	
	re <- cbind(re11, re21, re12, re22)	
	colnames(re) <- c("Z11", "Z21", "Z12", "Z22")
	return(re)
}

