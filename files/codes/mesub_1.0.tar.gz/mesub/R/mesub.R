
#require(statmod) # for gauss.quad
#require(numDeriv)
#require(compiler)

.packageName <- 'mesub'

ltm.me=function(tstar, delta, wstar, z, r, ncomp){
t<-NA
rm(t)
#
#
#
n=length(tstar)
if(length(delta)!=n) stop('Dimensions do not match')
if(nrow(wstar)!=n) stop('Dimensions do not match')
if(nrow(z)!=n) stop('Dimensions do not match')
wstar=wstar-mean(wstar) # recentering 
p=ncol(z)
m=ncol(wstar)
##### ordering the data
out=sort(tstar, index.return=T)
tstar=tstar[out$ix]
delta=delta[out$ix]
z=z[out$ix, ]
wstar=wstar[out$ix, ]
wbar=apply(wstar, 1, mean)
nofail=sum(delta) # number of failures 
failtime=tstar[delta==1] # the sorted failure times  

##### Naive method is use of Chen et al's method where we use wbar instead of x 
#
z=as.matrix(z)
storage.mode(z)<-"double"
index=(1:n)[delta==1]
pplus1=p+1
pplus2=p+2
maxcount=1000
tol=0.001
naivebeta=as.double(rep(0, pplus1))
# For the naive estimates 
capht=as.double(rep(0, nofail))
out100=.Fortran("solution1", output=naivebeta, output2=capht, delta=as.double(delta), failtime=as.double(failtime), 
index=as.integer(index), maxcount=as.integer(maxcount), n=as.integer(n), nofail=as.integer(nofail),  
p=as.integer(p), pplus1=as.integer(pplus1), r=as.double(r), tol=as.double(tol), tstar=as.double(tstar), wbar=as.double(wbar), z, PACKAGE='mesub')  
naive.estimate=out100$output
#
# Standard error calculation of the Chen's method 
cap_sigma_down_star=matrix(0, ncol=(pplus1), nrow=(pplus1))
cap_sigma_up_star=matrix(0, ncol=(pplus1), nrow=(pplus1))
storage.mode(cap_sigma_down_star)<-"double"
storage.mode(cap_sigma_up_star)<-"double"
#
out200=.Fortran("stdforsol1", beta=as.double(out100$output), capht=as.double(out100$output2), 
 output1=cap_sigma_down_star,  output2=cap_sigma_up_star, as.double(delta), as.double(failtime),  
 n=as.integer(n), as.double(wbar),  as.integer(nofail), p=as.integer(p), 
 pplus1=as.integer(pplus1), as.double(r), as.double(tstar), z, PACKAGE='mesub') 
#
naive.vcov=solve(out200$output1)%*%(out200$output2)%*%t(solve(out200$output1))/n
naive.se=sqrt(diag(naive.vcov)) 
#
#### Proposed approach 
#### The following four lines for hermite quadrature
nnodes=30
out=gauss.quad(nnodes,kind="hermite",alpha=0,beta=0)
xnodes=out$nodes
tnodes=xnodes
wnodes=xnodes
weight=exp(xnodes^2)*out$weights
#### This is our V
eta=as.integer(m/2)
if(eta==1) term1=wstar[, 1]/(2*eta) else term1=apply(wstar[, 1:eta], 1, sum)/(2*eta)
if((m-eta)==1) term2=wstar[, m]/(2*m-2*eta) else term2=apply(wstar[, (eta+1):m], 1, sum)/(2*m-2*eta)
v=term1-term2
#### this is our W
neww=term1+term2
#### bandwidth for estimation of f_U
h= bw.nrd(v)#width.SJ(v, method = "dpi")
density=function(val) sum(dnorm((v-val)/h))/(n*h)
zmat=cbind(1, z)
pplus2=p+2
newmat=matrix(0, nrow=n, ncol=nnodes)
for( i in 1: n)newmat[i, ]=apply(as.matrix(neww[i]-xnodes), 1, density)

#
if(ncomp==1){
#
#### Likelihood function of W, f(W|Z, \theta)=\int f(X|Z, \theta)f_U(W-X)dX
indloglk=function(para){
lk=rep(0, n)
for( i in 1: n){
tempo=sum(weight*newmat[i, ]*exp( -0.5*(xnodes-zmat[i, ]%*%para[1:pplus1])^2/para[pplus2])/sqrt(para[pplus2]))
tempo=max(tempo, 1e-300)
lk[i]=log(tempo)}
return(lk)
}
loglk=function(para)-sum(indloglk(para))


###### The following lines determines the initial parameter values for \theta
outold=lm(neww~z)
upperl=c(outold$coef+3*sqrt(diag(summary(outold)$cov.unscaled)), var(wbar))
lowerl=c(outold$coef-3*sqrt(diag(summary(outold)$cov.unscaled)), (var(wbar)-0.25*max(apply(wstar, 1, var))/m))
##### Estimation of $\theta$ by maximizing f(W|Z, \theta)
out=optim(c(outold$coef, 0.5*var(wbar)), loglk, method="L-BFGS-B", lower=lowerl, upper=upperl, hessian=T)
##### A_{W|Z}
cap.a.w.given.z=-solve(out$hessian/n)#Since loglk return negative log likelihood, 
# we insert a '-' sign to get the expected double derivative of the 
# log likelihood of W given Z and theta.


theta=out$par
gamma=out$par[1:pplus1]
sigma2x=out$par[pplus2]
###### f(X|Z, theta), 
fxgivenz=function(x, z0, theta)
{
gamma=out$par[1:pplus1]
sigma2x=out$par[pplus2]
den=rep(0, ncol=length(x))
den=exp(-0.5*(x-c(1, z0)%*%gamma)^2/sigma2x)/sqrt(2*pi*sigma2x)
list(density=den)
}
###### f(X|W, Z)
jointdensity=matrix(0, nrow=n, ncol=nnodes)
for( i in 1:n){
jointdensity[i, ]= fxgivenz(xnodes, z[i, ], theta)$density*newmat[i, ]*weight
tempo.sum=sum(jointdensity[i, ])
if(tempo.sum!=0) jointdensity[i, ]=jointdensity[i, ]/sum(jointdensity[i, ])
}
fxgivenwnz=jointdensity
###### Initialization of some parameters
ourbeta=as.double(rep(0, pplus1))
storage.mode(fxgivenwnz)<-"double"
caph=as.double(rep(0, n))
capht=as.double(rep(0, nofail))
###### Estimation of beta
###### Untill the standard error calculation is fixed, we turn off 
###### the following 5 lines. 
 newout=.Fortran("solution2", output1=ourbeta, output2=caph, output3=capht, delta=as.double(delta), 
 fxgivenwnz, failtime=as.double(failtime), index=as.integer(index), maxcount=as.integer(maxcount), 
 n=as.integer(n), nnodes=as.integer(nnodes), nofail=as.integer(nofail),  
 p=as.integer(p), pplus1=as.integer(pplus1), r=as.double(r), tol=as.double(tol), 
 tstar=as.double(tstar), wbar=as.double(neww), xnodes=as.double(xnodes), z, PACKAGE='mesub')  # alphabetical order 
###### Storing our estimates
our.estimate=newout$output1
##
}else if(ncomp==2){
##
#### Likelihood function of W, f(W|Z, \theta)=\int f(X|Z, \theta)f_U(W-X)dX
tpplus4<- 2*pplus2
tpplus5<- (2*pplus2)+1
indloglk=function(para){
lk=rep(0, n)
for( i in 1: n){
tempo=sum(weight*newmat[i, ]*((para[tpplus5]*exp( -0.5*(xnodes-zmat[i, ]%*%para[1:pplus1])^2/
para[pplus2])/sqrt(para[pplus2]))+((1-para[tpplus5])*exp( -0.5*(xnodes-zmat[i, ]%*%para[
(pplus2+1):(pplus2+pplus1)])^2/para[tpplus4])/sqrt(para[tpplus4]))))
tempo=max(tempo, 1e-300)
lk[i]=log(tempo)}
return(lk)
} 
loglk=function(para)-sum(indloglk(para))


###### The following lines determines the initial parameter values for \theta
outold=lm(neww~z)
upperl=c(outold$coef+3*sqrt(diag(summary(outold)$cov.unscaled)), 1.5*var(wbar))
lowerl=c(outold$coef-3*sqrt(diag(summary(outold)$cov.unscaled)), 0.2*(var(wbar)-0.25*max(apply(wstar, 1, var))/m))
##### Estimation of $\theta$ by maximizing f(W|Z, \theta)
initial=c(rep(c(outold$coef, 0.5*var(wbar)), ncomp)+runif(tpplus4, 0, 0.01), rep(1, (ncomp-1))/ncomp)
upperl=c(rep(upperl, ncomp)+runif(tpplus4, 0, 0.01), rep(0.999, (ncomp-1))); 
lowerl=c(rep(lowerl, ncomp)+runif(tpplus4, 0, 0.01), rep(0.001, (ncomp-1)))

out=optim(initial, loglk, method="L-BFGS-B", lower=lowerl, upper=upperl, hessian=T)
#print('it worked')
#print('out$par=');
#print(out$par)
##### A_{W|Z}
cap.a.w.given.z=-solve(out$hessian/n)# Since loglk return negative log likelihood, 
# we insert a '-' sign to get the expected double derivative of the 
# log likelihood of W given Z and theta.

theta=out$par
###### f(X|Z, theta), 
fxgivenz=function(x, z0, theta)
{  
gamma1=theta[1:pplus1]
sigma12x=theta[pplus2]
gamma2=theta[(pplus2+1):(pplus2+pplus1)]
sigma22x=theta[tpplus4]
pwt=theta[tpplus5]
den=rep(0, ncol=length(x))
den=(pwt*exp(-0.5*(x-c(1, z0)%*%gamma1)^2/sigma12x)/sqrt(2*pi*sigma12x))+((1-pwt)*exp(-0.5*(x-c(1, z0)%*%gamma2)^2/sigma22x)/sqrt(2*pi*sigma22x))
list(density=den)
}
###### f(X|W, Z)
jointdensity=matrix(0, nrow=n, ncol=nnodes)
for( i in 1:n){
jointdensity[i, ]= fxgivenz(xnodes, z[i, ], theta)$density*newmat[i, ]*weight
tempo.sum=sum(jointdensity[i, ])
if(tempo.sum!=0) jointdensity[i, ]=jointdensity[i, ]/sum(jointdensity[i, ])
}
fxgivenwnz=jointdensity
###### Initialization of some parameters
ourbeta=as.double(rep(0, pplus1))
storage.mode(fxgivenwnz)<-"double"
caph=as.double(rep(0, n))
capht=as.double(rep(0, nofail))
###### Estimation of beta
###### Untill the standard error calculation is fixed, we turn off 
###### the following 5 lines. 
 newout=.Fortran("solution2", output1=ourbeta, output2=caph, output3=capht, delta=as.double(delta), 
 fxgivenwnz, failtime=as.double(failtime), index=as.integer(index), maxcount=as.integer(maxcount), 
 n=as.integer(n), nnodes=as.integer(nnodes), nofail=as.integer(nofail),  
 p=as.integer(p), pplus1=as.integer(pplus1), r=as.double(r), tol=as.double(tol), 
 tstar=as.double(tstar), wbar=as.double(neww), xnodes=as.double(xnodes), z, PACKAGE='mesub')  # alphabetical order 
###### Storing our estimates
our.estimate=newout$output1
###
} else{
###
#### Likelihood function of W, f(W|Z, \theta)=\int f(X|Z, \theta)f_U(W-X)dX
tpplus4<- 2*pplus2
tpplus5<- (2*pplus2)+1
thpplus6<- ncomp*pplus2
thpplus7<- thpplus6+1
thpplus8<- thpplus6+2

indloglk=function(para){ # This is integrated log likelihood for W given Z. This function is 
# used for optimization purpose, in other words to obtain the MLE of \theta. 
lk=rep(0, n)
pwt1=exp(para[thpplus7])/(1+exp(para[thpplus7])+exp(para[thpplus8]))
pwt2=exp(para[thpplus8])/(1+exp(para[thpplus7])+exp(para[thpplus8]))

for(i in 1: n){
tempo=sum(weight*newmat[i, ]*((pwt1*exp( -0.5*(xnodes-zmat[i, ]%*%para[1:pplus1])^2/
para[pplus2])/sqrt(para[pplus2]))+(pwt2*exp( -0.5*(xnodes-zmat[i, ]%*%para[
(pplus2+1):(pplus2+pplus1)])^2/para[tpplus4])/sqrt(para[tpplus4]))+((1-pwt1-pwt2)*
exp( -0.5*(xnodes-zmat[i, ]%*%para[(tpplus4+1):(tpplus4+pplus1)])^2/para[thpplus6])/sqrt(para[thpplus6]))))
tempo=max(tempo, 1e-300)
lk[i]=log(tempo)}
return(lk)
} 
loglk=function(para)-sum(indloglk(para))


indloglk2=function(mypara){ # This is integrated log likelihood for W given Z. This function is 
# used for calculating the hessian matrix for \theta at its MLE. 
lk=rep(0, n)
pwt1=mypara[thpplus7]
pwt2=mypara[thpplus8]
for(i in 1: n){
tempo=sum(weight*newmat[i, ]*((pwt1*exp( -0.5*(xnodes-zmat[i, ]%*%mypara[1:pplus1])^2/
mypara[pplus2])/sqrt(mypara[pplus2]))+(pwt2*exp( -0.5*(xnodes-zmat[i, ]%*%mypara[
(pplus2+1):(pplus2+pplus1)])^2/mypara[tpplus4])/sqrt(mypara[tpplus4]))+((1-pwt1-pwt2)*
exp( -0.5*(xnodes-zmat[i, ]%*%mypara[(tpplus4+1):(tpplus4+pplus1)])^2/mypara[thpplus6])/sqrt(mypara[thpplus6]))))
tempo=max(tempo, 1e-300)
lk[i]=log(tempo)}
return(sum(lk))
} 

###### The following lines determines the initial parameter values for \theta for the purpose of optimization 
outold=lm(neww~z)
upperl=c(outold$coef+3*sqrt(diag(summary(outold)$cov.unscaled)), 1.5*var(wbar))
lowerl=c(outold$coef-3*sqrt(diag(summary(outold)$cov.unscaled)), 0.2*(var(wbar)-0.25*max(apply(wstar, 1, var))/m))
##### Estimation of $\theta$ by maximizing f(W|Z, \theta)
initial=c(rep(c(outold$coef, 0.5*var(wbar)), ncomp)+runif(thpplus6, 0, 0.01), rep(1, (ncomp-1))/ncomp)
upperl=c(rep(upperl, ncomp)+runif(thpplus6, 0, 0.01), rep(8, (ncomp-1))); 
lowerl=c(rep(lowerl, ncomp)+runif(thpplus6, 0, 0.01), rep(-5, (ncomp-1)))

out=optim(initial, loglk, method="L-BFGS-B", lower=lowerl, upper=upperl, hessian=T)
#print('it worked')
#print('out$par=');
#print(out$par)
##### A_{W|Z}= E[\partial^2log\{f(W|Z, \theta)\}/\partial \theta\theta^T]
theta=out$par
theta[thpplus7]=exp(out$par[thpplus7])/(1+exp(out$par[thpplus7])+exp(out$par[thpplus8]))
theta[thpplus8]=exp(out$par[thpplus8])/(1+exp(out$par[thpplus7])+exp(out$par[thpplus8]))
#cap.a.w.given.z=-solve(jacobian(indloglk2, theta)/n)

cap.a.w.given.z=solve(hessian(indloglk2, theta, method="Richardson")/n) # 

###### f(X|Z, theta), 
fxgivenz=function(x, z0, theta)
{
pwt1=theta[thpplus7]
pwt2=theta[thpplus8]
gamma1=theta[1:pplus1]
sigma12x=theta[pplus2]
gamma2=theta[(pplus2+1):(pplus2+pplus1)]
sigma22x=theta[tpplus4]
gamma3=theta[(tpplus4+1):(tpplus4+pplus1)]
sigma32x=theta[thpplus6]
den=rep(0, ncol=length(x))
den=(pwt1*exp(-0.5*(x-c(1, z0)%*%gamma1)^2/sigma12x)/sqrt(2*pi*sigma12x))+(pwt2*exp(-0.5*(x-c(1, z0)%*%gamma2)^2/sigma22x)/
sqrt(2*pi*sigma22x))+((1-pwt1-pwt2)*exp(-0.5*(x-c(1, z0)%*%gamma3)^2/sigma32x)/sqrt(2*pi*sigma32x))
list(density=den)
}
###### f(X|W, Z)
jointdensity=matrix(0, nrow=n, ncol=nnodes)
for( i in 1:n){
jointdensity[i, ]= fxgivenz(xnodes, z[i, ], theta)$density*newmat[i, ]*weight
tempo.sum=sum(jointdensity[i, ])
if(tempo.sum!=0) jointdensity[i, ]=jointdensity[i, ]/sum(jointdensity[i, ])
}
fxgivenwnz=jointdensity
###### Initialization of some parameters
ourbeta=as.double(rep(0, pplus1))
storage.mode(fxgivenwnz)<-"double"
caph=as.double(rep(0, n))
capht=as.double(rep(0, nofail))
###### Estimation of beta
###### Untill the standard error calculation is fixed, we turn off 
###### the following 5 lines. 
 newout=.Fortran("solution2", output1=ourbeta, output2=caph, output3=capht, delta=as.double(delta), 
 fxgivenwnz, failtime=as.double(failtime), index=as.integer(index), maxcount=as.integer(maxcount), 
 n=as.integer(n), nnodes=as.integer(nnodes), nofail=as.integer(nofail),  
 p=as.integer(p), pplus1=as.integer(pplus1), r=as.double(r), tol=as.double(tol), 
 tstar=as.double(tstar), wbar=as.double(neww), xnodes=as.double(xnodes), z, PACKAGE='mesub')  # alphabetical order 
###### Storing our estimates
our.estimate=newout$output1
}

# AIC calculation for the following likelihood: \sum log f(W|Z) = \sum log (\int f(W|X)*f(X|Z)dX)
storeAIC=(2*length(theta))+(2*out$value)

# BIC calculation for the following likelihood: \sum log f(W|Z) = \sum log (\int f(W|X)*f(X|Z)dX)
storeBIC=(log(n)*length(theta))+(2*out$value)

### Standard error calculation
###
###
storage.mode(cap.a.w.given.z)<-"double"
cap_sigma_1=matrix(0, ncol=pplus1, nrow=pplus1)
sigma_star=matrix(0, ncol=pplus1, nrow=pplus1)
storage.mode(cap_sigma_1)<-"double"
storage.mode(sigma_star)<-"double"
######################
storeden=NULL;
den=as.double(rep(0, nnodes))
for(i in 1:n){
outden=.Fortran("densityofxvecgivenwnz", output=den, h=as.double(h),  n=as.integer(n), 
ncomp=as.integer(ncomp), nnodes=as.integer(nnodes), ntheta=as.integer(length(theta)), 
p=as.integer(p), theta=as.double(theta), v=as.double(v), as.double(neww[i]),
as.double(weight), as.double(xnodes), as.double(z[i, ]), PACKAGE='mesub')
storeden=rbind(storeden, outden$output)
}
#print(apply(storeden,1,mean))
storage.mode(storeden)<-"double"
storewz=NULL;
storexz=NULL;
lpipel=NULL;
lpipeu=NULL;
#for(l in 4:(nofail-3)){
for(l in 1:nofail){
#print(l)
###
capy=rep(0, n)
capy[tstar>=failtime[l]]<-1;

#print(capy)
if(mean(capy)>=0.85) {lpipel=c(lpipel, l)} else {
if(mean(capy)<=0.15){lpipeu=c(lpipeu, l)} else {
outwz=glm(capy~z+neww, family=binomial)
storewz=rbind(storewz, outwz$coef)

lowerl= as.numeric(summary(outwz)$coef[, 1]-2* summary(outwz)$coef[, 2])
upperl= as.numeric(summary(outwz)$coef[, 1]+2* summary(outwz)$coef[, 2])

#print(lowerl); print(upperl)
#if(mean(capy)>0.975 |mean(capy)<0.025) {outwz=glm(capy~z+neww, family=poisson)} else{ 
#outwz=glm(capy~z+neww, family=binomial)}
#outwz=glm(capy~z+neww, family=binomial)
#storewz=rbind(storewz, outwz$coef)
###
lglkfnc=function(gamma){
lglk=as.double(0)
outneglk= .Fortran("neglkfunc",as.double(capy), as.double(gamma), output=lglk,
n=as.integer(n), nnodes=as.integer(nnodes),  p=as.integer(p), pplus2=as.integer(pplus2), 
storeden, as.double(xnodes),z, PACKAGE='mesub')
return(outneglk$output)
}

if(is.nan(lglkfnc(upperl)))  upperl=as.numeric(summary(outwz)$coef[, 1]+1*summary(outwz)$coef[, 2])
if(is.nan(lglkfnc(lowerl)))  lowerl=as.numeric(summary(outwz)$coef[, 1]-1*summary(outwz)$coef[, 2])
#print('hi');
#print('l='); print(l);
#print('upperl='); print(upperl)
outxz=optim(rep(0.5, pplus2), lglkfnc, method="L-BFGS-B", lower=lowerl, upper=upperl)
storexz=rbind(storexz, outxz$par)
}
}
}
######################
storage.mode(storexz)<-"double"
storage.mode(storewz)<-"double"
######################
stdcal=.Fortran("stdforsol2", beta=as.double(newout$output1), capht=as.double(newout$output3), 
 output1=cap_sigma_1,  
delta=as.double(delta), failtime=as.double(failtime), h=as.double(h),  cap.a.w.given.z,   
 ll=as.integer(length(lpipel)), lu= as.integer(length(lpipeu)), n=as.integer(n), ncomp=as.integer(ncomp), 
 neww=as.double(neww), nnodes=as.integer(nnodes), nofail=as.integer(nofail), 
ns=as.integer(nofail-length(lpipel)-length(lpipeu)),  ntheta=as.integer(length(theta)),
 p=as.integer(p), pplus1=as.integer(pplus1), pplus2=as.integer(pplus2),  r=as.double(r), 
sd_neww=as.double(sd(neww)), sd_z=as.double(apply(z, 2, sd)), output2=sigma_star, 
 storewz, storexz, 
theta=as.double(theta), tstar=as.double(tstar), 
v=as.double(v), weight=as.double(weight), xnodes=as.double(xnodes), z, PACKAGE='mesub')

our.vcov=solve(stdcal$output1)%*%(stdcal$output2)%*%t(solve(stdcal$output1))/n
#source("std_data.R")
our.se= sqrt(diag(our.vcov))
#
result<-list(naive.estimate, naive.vcov, naive.se, our.estimate, our.vcov, our.se, 
storeAIC, storeBIC)

names(result)<-c("naive.estimate", "naive.vcov", "naive.se", "our.estimate", "our.vcov", "our.se", "AIC", "BIC")
return(result)}

ltm.me2=cmpfun(ltm.me)
