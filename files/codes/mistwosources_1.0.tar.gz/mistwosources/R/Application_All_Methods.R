
#####################################################################
# Clear memory and set the working directory
#####################################################################
# In this program it is set all the function according to the methods 1-5
#####################################################################

#rm(list = ls())
#####################################################################
#Program for fit our generalization on Hausman`s approach on \pi_1=probit and \pi_0=0.( Our METHOD 3)
#####################################################################
misclass_phi1=function (y1=y1, y2=y2,x=x,z1=z1,z2=z2,  bmat = NULL, print.summary = TRUE) 
{
      y_both <- as.numeric(y1+y2>=1)
      form<- y_both~x+z1+z2
      probit <- glm(form, family = binomial(link = "probit")) 
  ysum <- model.frame(form)[, 1]
  xzmat <- model.matrix(form) # Design matrix (1,x,z1,z2)
  nxz = ncol(xzmat)  
  nz<-ncol(as.matrix(z1))+ncol(as.matrix(z2))
  #probitX <- glm(ysum~ xzmat[,2:(nxz-nz)], family = binomial(link = "probit"))  # fit probit  considering just  x1+x2+x3+...xp
  probitX <- glm(ysum~ x, family = binomial(link = "probit"))  # fit probit  considering just  x
  xmat<- model.matrix(ysum~ x) # Design matrix (1,x)
  if (identical(bmat,NULL)){
    nbxzmat <- length(probit$coef)
    bxmat <- as.vector(probitX$coef)
    bxzmat <- as.vector(probit$coef)
    bmat<-c(bxmat,bxzmat)
  }
  nx = ncol(xmat)
  
  nk = length(bmat) #
  bstart <-  bmat
  nameb=rep("beta",nx)
  namee=rep("eta",nxz)
  namebeta=outer(nameb, seq(0,(nx-1)), function(x,y) paste(x,y,sep=""))[1,]
  nameeta=outer(namee, seq(0,(nxz-1)), function(x,y) paste(x,y,sep=""))[1,]
  namebstar<-c(namebeta,nameeta) 
  names(bstart)<-namebstar
  
  logl <- function(b) {
    eysum<-(1-pnorm(xzmat%*% b[(nx+1):nk]))*pnorm(xmat%*%b[1:nx]) 
    out<--sum(ifelse(ysum==1,log(eysum),log(1-eysum)))
    return(out)
  }
  
  nlfit<-optim(bstart,logl, gr=NULL, method="BFGS",control=list(maxit=500), hessian=TRUE) # the function probit.lf is defined above
  # For default maxit=100 and the iteration limit may need to be larger to get convergence. 
  vmat <- solve(nlfit$hessian)
  stderr <- sqrt(abs(diag(vmat)))
  tval <- nlfit$par/stderr
  pval <- 2 * (1 - pnorm(abs(tval)))
  
  cname <- c("Estimate", "Std. Error", "z-value", "Pr(>|z|)")
  if (print.summary == TRUE) {
    outmat <- cbind(nlfit$par, stderr, tval, pval)
    #rownames(outmat) <- names(probit$coef)
    colnames(outmat) <- cname
    print(round(outmat, 5))
    cat(" ", "\n")
  }
  
  out1 <- list(nlfit$par, stderr, vmat, nlfit$convergence, 
               -nlfit$value)
  names(out1) <- c( "estimate", "stderr", "vmat","convergence", "minimum")
  return(out1)  
}
#####################################################################
#Program for fit our proposed model considering \alpha_1 and \alpha_2 equal to a constant (parameter).(Method  4)
#####################################################################
misclass_a1_a2=function (y1=y1,y2=y2,x=x, a1 =0.001, a2 =  0.001, bmat =NULL, print.summary = TRUE)
{
  y_both <- as.numeric(y1+y2>=1)
  form<- y_both~x
  probit <- glm(form, family = binomial(link = "probit"))
  cat("Standard Probit Estimates", "\n")
  print(summary(probit))
  xmat <- model.matrix(form)
  if (identical(bmat, NULL)) {
    bmat <- probit$coef
  }
  nk = length(bmat)
  y <- model.frame(form)[, 1]
  a1 = ifelse(identical(a1,  0.001), 0.001, a1)
  a2 = ifelse(identical(a2,  0.001), 0.001, a2)
  
  bstart <- c(bmat, qnorm(a1), qnorm(a2))
  nvect<-c("a1", "a2")
  names(bstart)<-c(names(probit$coef), paste("qnorm(", nvect, ")", sep = ""))
  logl <- function(b) {
    y00 <- (1 - y1)*(1 - y2)
    y01 <- (1 - y1)*y2
    y10 <- y1*(1 - y2) 
    y11<- y1*y2
    
    p00<- 1- pnorm(xmat %*% b[1:nk])+ pnorm(b[nk + 1])* pnorm(b[nk + 2])* pnorm(xmat %*% b[1:nk])
    logprob00 <- log(p00)
    p01<- pnorm(b[nk + 1])*(1- pnorm(b[nk + 2]))* pnorm(xmat %*% b[1:nk])
    logprob01 <- log(p01)
    p10<- (1-pnorm(b[nk + 1]))* pnorm(b[nk + 2])* pnorm(xmat %*% b[1:nk])
    logprob10 <- log(p10)
    p11<- (1-pnorm(b[nk + 1]))*(1- pnorm(b[nk + 2]))* pnorm(xmat %*% b[1:nk])
    logprob11 <- log(p11)
    y00t <- t(y00)
    y01t <- t(y01)
    y10t <- t(y10)
    y11t <- t(y11)
    out <- - sum(y00t%*%logprob00 + y01t%*%logprob01 + y10t%*%logprob10 +
                   y11t%*%logprob11)           
    return(out)
  }
  nlfit<- optim( bstart,logl,method="L-BFGS-B",control=list(maxit=500), hessian = TRUE)
  vmat <- solve(nlfit$hessian)
  stderr <- sqrt(abs(diag(vmat)))
  tval <- nlfit$par/stderr
  pval <- 2 * (1 - pnorm(abs(tval)))
  nall <- length(nlfit$par)
  nk1 = nk + 1
  amat <- pnorm(nlfit$par[nk1:nall])
  tmat <- tval[nk1:nall]
  smat <- abs(amat/tmat)
  nvect <- c("a1", "a2")
  names(nlfit$par[nk1:nall]) <- nvect
  names(amat) <- nvect
  names(tmat) <- nvect
  names(smat) <- nvect
  cname <- c("Estimate", "Std. Error", "z-value", "Pr(>|z|)")
  if (print.summary == TRUE) {
    outmat <- cbind(nlfit$par, stderr, tval, pval)
    rownames(outmat) <- c(names(probit$coef), paste("qnorm(", 
                                                    nvect, ")", sep = ""))
    colnames(outmat) <- cname
    cat("nlm estimates", "\n")
    cat(" ", "\n")
    print(round(outmat, 5))
    cat(" ", "\n")
    cat("Estimated misclassification probabilities:", "\n")
    outmat <- cbind(amat, smat, tmat, 2 * (1 - pnorm(abs(tmat))))
    rownames(outmat) <- nvect
    colnames(outmat) <- cname
    print(round(outmat, 5))
    cat(" ", "\n")
  }
  
  out1 <- list(nlfit$par, stderr, vmat, nlfit$convergence, 
               -nlfit$value, amat[1], amat[2],smat)
  names(out1) <- c( "estimate", "stderr", "vmat","convergence", "minimum","a1", "a2", "smat")
  return(out1)  
}

#####################################################################
#Program for to get Loglik. for the model when \alpha_1(X,Z) and \alpha_2(X,Z) are probit function. (Method 5)
#####################################################################
misclass_a1xz_a2xz=function (y1=y1,y2=y2,x,z1,z2, print.summary = TRUE)
{
  y_both <- as.numeric(y1+y2>=1)
  form<-y_both~ x+z1+z2
  #probit <- glm(form, family = binomial(link = "probit"))
  xzmat <- model.matrix(form) #Design matrix (1,x,z1,z2)
  #bmat <- probit$coef
  ysum <- model.frame(form)[, 1]
  #probitX <- glm(ysum~ xzmat[,2:(nxz-2)], family = binomial(link = "probit"))  # fit probit  considering just  x1+x2+x3+...xp
  nxz = ncol(xzmat) 
  xmat<- model.matrix(ysum~ x) # Design matrix (1,x)
  nx<-ncol(xmat)
  nz1<-ncol(as.matrix(z1))
  nz2<-ncol(as.matrix(z2))
  nz<-nz1+nz2
  xmat<- model.matrix(ysum~ xzmat[,2:(nxz-nz)]) # Design matrix (1,x)

  X0<-xzmat[,1:(nx)]
  X1<-xzmat[,1:(nx+nz1)]
  X2<-cbind(xzmat[,1:nx],xzmat[,(nx+nz1+1):(nx+nz)])
  
  probit.lf <- function(beta) {
    
    F0 <- pnorm(X0%*%beta[1:nx]) 
    F1 <- pnorm(X1%*%beta[(nx+1):(2*nx+nz1)]) 
    F2 <- pnorm(X2%*%beta[(2*nx+nz1+1):(3*nx+nz)]) 
    
    
    y00 <- (1 - y1)*(1 - y2)
    y01 <- (1 - y1)*y2
    y10 <- y1*(1 - y2) 
    y11<- y1*y2
    
    
    prob00 <- 1 - F0 + F1*F2*F0 
    logprob00 <- log(prob00)
    
    prob01 <- F1*(1-F2)*F0
    logprob01 <- log(prob01)
    
    prob10 <-  (1- F1)*F2*F0
    logprob10 <- log(prob10)
    
    prob11 <-  (1- F1)*(1-F2)*F0
    logprob11 <- log(prob11)
    
    y00t <- t(y00)
    y01t <- t(y01)
    y10t <- t(y10)
    y11t <- t(y11)
    
    logl <- -sum(y00t%*%logprob00 + y01t%*%logprob01 + y10t%*%logprob10 + y11t%*%logprob11)
    return(logl)
  }
  
  
  K <- as.numeric(ncol(X0) + ncol(X1) + ncol(X2) )
  startv = rep(0,K)
  
  probitmodel.Fa1.Fa2 <- optim(startv, probit.lf, gr=NULL, method="BFGS",control=list(maxit=500), hessian=TRUE) # the function probit.lf is defined above
  coeffs.probit.Fa1.Fa2  <- probitmodel.Fa1.Fa2$par
  covmat.probit.Fa1.Fa2 <- solve(probitmodel.Fa1.Fa2$hessian)
  stderr.probit.Fa1.Fa2  <- sqrt(diag(covmat.probit.Fa1.Fa2))
  
  nameb=rep("beta",nx)
  namee1=rep("eta1",(nx+nz1))
  namee2=rep("eta2",(nx+nz2))
  
  namebeta=outer(nameb, seq(0,(nx-1)), function(x,y) paste(x,y,sep=""))[1,]
  nameeta1=outer(namee1, seq(0,(nx+nz1-1)), function(x,y) paste(x,y,sep=""))[1,]
  nameeta2=outer(namee2, seq(0,(nx+nz2-1)), function(x,y) paste(x,y,sep=""))[1,]
  
  namepar<-c(namebeta,nameeta1,nameeta2) 
  names(coeffs.probit.Fa1.Fa2 )<-namepar
  
  #return(rbind(coeffs.probit.Fa1.Fa2,stderr.probit.Fa1.Fa2 ))
  
  ##############
  vmat <-   covmat.probit.Fa1.Fa2
  stderr <-  stderr.probit.Fa1.Fa2
  tval <-   coeffs.probit.Fa1.Fa2/stderr
  pval <- 2 * (1 - pnorm(abs(tval)))
  nall <- length(coeffs.probit.Fa1.Fa2)
  #nk1 = nk + 1
  #amat <- pnorm(nlfit$par[nk1:nall])
  #tmat <- tval[nk1:nall]
  #smat <- abs(amat/tmat)
  #nvect <- c("a1", "a2")
  #names(nlfit$par[nk1:nall]) <- nvect
  #names(amat) <- nvect
  #names(tmat) <- nvect
  #names(smat) <- nvect
  cname <- c("Estimate", "Std. Error", "z-value", "Pr(>|z|)")
  if (print.summary == TRUE) {
    outmat <- cbind(coeffs.probit.Fa1.Fa2, stderr, tval, pval)
    colnames(outmat) <- cname
    cat("nlm estimates", "\n")
    cat(" ", "\n")
    print(round(outmat, 5))
    cat(" ", "\n")
  }
  
  out1 <- list(coeffs.probit.Fa1.Fa2, probitmodel.Fa1.Fa2$value,  probitmodel.Fa1.Fa2$convergence, probitmodel.Fa1.Fa2$message, probitmodel.Fa1.Fa2$hessian)
              
  names(out1) <- c( "estimate", "value", "convergence", "message","hessian")
  return(out1)  
}
