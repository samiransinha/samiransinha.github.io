.packageName<-"bayesmcmc4m3"
bmcmcm3=function(response, error.free.covariates, IV, surrogate, mydata, nmcmc, burnin, priorvarvec, propscale){
if(missing(mydata)) stop('Input data are missing')
if(missing(nmcmc)) nmcmc=40000
if(nmcmc<1000) stop('The number of MCMC iterations is too small')
if(missing(burnin)) burnin=min(5000, 0.25*nmcmc)
if(missing(propscale)) propscale=1


myn=nrow(mydata)

ourw= get(surrogate, mydata)
nx=length(unique(ourw))
naive.model.y<-as.formula(paste(response, paste(paste("as.factor(", surrogate, ")", sep=""),  paste(error.free.covariates, collapse="+"), sep="+"), sep="~"))

out1=glm(naive.model.y, family=binomial, data=mydata)
modelmatz=model.matrix(out1)[, -c(1:nx)] 
storage.mode(modelmatz)<-"double"
nz=ncol(modelmatz)

#environment(naive.model.w2)<-environment()

#store.coef=NULL;
#for( j in 2: nx){
#id=(1:myn)[ourw==1 | ourw==j]
#neww=ourw[id]

#naive.model.w2<-paste("as.factor(neww)",  paste(c(IV, error.free.covariates), collapse="+"),  sep="~")
#out3=glm( naive.model.w2, family=binomial, data.frame(mydata[id, ], neww) )
#store.coef=c(store.coef, out3$coef)
#}
naive.model.w2<-as.formula(paste(surrogate,  paste(c(IV, error.free.covariates), collapse="+"),  sep="~"))
print(naive.model.w2)
out2=multinom(formula=naive.model.w2, data=mydata)



#print(naive.model.w2)
modelmatxstarz=model.matrix(out2)[, -1]
storage.mode(modelmatxstarz)<-"double"
nxstarz=ncol(modelmatxstarz)


#initial=c(as.numeric(out1$coef),  
#          as.numeric(store.coef), 
#          rep(0, (nx*(nx-1)))
#          )
initial=c(as.numeric(out1$coef),  
          as.numeric( as.vector(t(summary(out2)$coefficients))), 
          rep(0, (nx*(nx-1)))
          )

myk=length(initial)
if(missing(priorvarvec)) priorvarvec=rep(2, myk)
#priorvarvec=rep(2, myk)
mymu=initial
head(mydata)


#dyn.load("bayesmcmc4m3.so")
set.seed(10)
inputseed=100000*runif(1) 

store=matrix(0, nrow=nmcmc, ncol=myk)
storage.mode(store)<-"double"
j0=min(as.integer(nmcmc*0.025), 1000)
  
print('Be patient, it is a time consuming step. For example, with sample size 500 and 40,000 MCMC iterations, it may take up to 70 secs on an Intel(R) Xeon(R) CPU E5-2690 0 @ 2.90GHz with 4 GB RAM machine.')  

outm3=.Fortran("insvbayesm3", inputseed1=as.integer(inputseed), 
               j0=as.integer(j0), as.double(initial), 
                modelmatxstarz, modelmatz,
                mu=as.double(mymu), as.integer(myk),  
                myw=as.integer(mydata$myw),
                myy=as.double(mydata$y),  
                n=as.integer(myn), nmcmc=as.integer(nmcmc),
                as.integer(nx), as.integer(nxstarz), as.integer(nz),  
                priorvar=as.double(priorvarvec), propscale=as.double(propscale), output1=store, PACKAGE="bayesmcmc4m3")  
  
# MCMC samples after the burnin
mcmcsamples=outm3$output1[-c(1:burnin), ]

qntfun=function(i) quantile(mcmcsamples[, i], prob=c(0.025, 0.975))
npara.ygivenxz=1+(nx-1)+nz

myresultm3=c(apply(mcmcsamples[, 1:npara.ygivenxz], 2, mean), 
apply(mcmcsamples[, 1:npara.ygivenxz], 2, median), 
apply(mcmcsamples[, 1:npara.ygivenxz], 2, sd), 
as.numeric(unlist(lapply(1:npara.ygivenxz, qntfun))))


myresultm2=list(naive.estimates= summary(out1)$coefficients[, 1], naive.se=summary(out1)$coefficients[, 2])

myresultm3=list(postmean=apply(mcmcsamples[, 1:npara.ygivenxz], 2, mean), 
postmedian=apply(mcmcsamples[, 1:npara.ygivenxz], 2, median), 
postsd=apply(mcmcsamples[, 1:npara.ygivenxz], 2, sd), 
credibleinterval=as.numeric(unlist(lapply(1:npara.ygivenxz, qntfun))))

myresult= list(M2= myresultm2, M3= myresultm3)
return(myresult)}


.First.lib <- function(lib, pkg) {
library.dynam("bayesmcmc4m3", pkg, lib)
}
