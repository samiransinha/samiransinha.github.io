Each folder contains one type of congenital malformation as well as the data and codes to generate forest plot and funnel plot.

contact information:

rpage@tamu.edu sinha@stat.tamu.edu wy.huang1122@gmail.com



