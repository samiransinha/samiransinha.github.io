#
#
#
#
#
#
##
# This is the proposed semiparametric Bayesian approach. 
# This program also includes naive and regression calibration approach.  
##
.packageName<-"smmrbayes"
semipbayes=function(time=v, status=delta, w, covariate=NULL, 
mean.beta=NULL, sigma2.beta=NULL, nmcmc=nmcmc, numb.burn=NULL, numb.thin=NULL, capb=200){
n1=length(time);
n2=length(status);
n3=nrow(w);
m=ncol(as.matrix(w))
n=length(time)
if(m<2) stop('w must have at least two replications')
if(!is.null(covariate)){
covariate=as.matrix(covariate)
n4=nrow(covariate);
if(min(n1, n2, n3, n4)!= max(n1, n2, n3, n4)) stop('Dimension mismatch')
if(is.na(sum(time)+sum(status)+sum(w)+sum(covariate)))  stop('There is a missing value')
#
#
# Naive method 
wbar=apply(w, 1, mean)
wbar=wbar-mean(wbar)
f <- bj(Surv(time,status) ~ covariate+wbar, link="log", control=list(iter.max=500))
store.f=f$coef[-1]
store.f.sd=sqrt(diag(f$var))[-1]
####
#### Regression calibration 
sum1=0
for( i in 1:(m-1)){
  for( j in (i+1):m){
   sum1=sum1+sum((w[, i]-w[, j])^2)}}
   sigma2.w.x=sum1/(m*choose(m, 2)*2*n)
#
wbar=apply(w, 1, mean)
wbar=wbar-mean(wbar)
fout=lm(wbar~covariate)
sigma2.x.z=sum((wbar- cbind(1, covariate)%*%fout$coef)^2)/(n-ncol(covariate))-sigma2.w.x
xhat=(wbar/sigma2.w.x+  cbind(1, covariate)%*%fout$coef/sigma2.x.z)/(1/sigma2.w.x+1/sigma2.x.z)
newf <- bj(Surv(time,status) ~ covariate+xhat, link="log", control=list(iter.max=500))
inputvarx=1/(1/sigma2.w.x+1/sigma2.x.z)
#####
##### Standard error calculation bootstrap method 
#####
bootest=NULL;
orgtime=time; orgstatus=status; orgw=w; orgcovariate=as.matrix(covariate);
for( it in 1:capb){
set.seed(it)
index=sample((1:n), replace=T)
time=orgtime[index]; 
status=orgstatus[index]
w=orgw[index, ]
covariate=as.matrix(orgcovariate[index, ])
###
sum1=0
for( i in 1:(m-1)){
  for( j in (i+1):m){
   sum1=sum1+sum((w[, i]-w[, j])^2)}}
   sigma2.w.x=sum1/(m*choose(m, 2)*2*n)
#
wbar=apply(w, 1, mean)
wbar=wbar-mean(wbar)
fout=lm(wbar~covariate)
sigma2.x.z=sum((wbar- cbind(1, covariate)%*%fout$coef)^2)/(n-ncol(covariate))-sigma2.w.x
xhat=(wbar/sigma2.w.x+  cbind(1, covariate)%*%fout$coef/sigma2.x.z)/(1/sigma2.w.x+1/sigma2.x.z)
bootf <- bj(Surv(time,status) ~ covariate+xhat, link="log", control=list(iter.max=500))
###
bootest=rbind(bootest, bootf$coef)
}
###
### Proposed Bayesian method 
####
v=orgtime; delta=orgstatus; w=orgw; z=as.matrix(orgcovariate);
p=ncol(z)
w=as.matrix(w)
m=ncol(w)
ntm=n*m
nburn=1000;
if(!is.null(numb.burn)) nburn=numb.burn
nthin=10;
if(!is.null(numb.thin)) nthin=numb.thin
nmc=nmcmc-nburn
if(nmc<2*nthin) stop('nmcmc is very  small')
w=w-mean(as.numeric(w))
wbar = apply(w, 1, mean)
########
inputseed=100000*runif(1)  
###
tau_e = 2 
tau_u= 2.
tau_x = 2.0  
#### determination of prior parameters 
#### for x
newa=var(wbar)-min(apply(w, 1, var))/m;
newb=newa
a_sigmax=newa^2/newb+2;
b_sigmax= 1/(newa*(a_sigmax-1) )
### for u
newa=median(apply(w, 1, var))
newb=newa
a_sigmau=newa^2/newb+2;
b_sigmau= 1/(newa*(a_sigmau-1) )	
#### for e
newa=var(log(v)[delta==1])
newb=newa
a_sigmae=1*newa^2/newb+2;
b_sigmae=1/ (newa*(a_sigmae-1) )
###########
newmax=20*var(wbar)
###########
a_alpha=1;
b_alpha=1;
tempo_1x=(
lgamma(a_sigmax+0.5)-log(sqrt(2*pi*(1+tau_x)))-a_sigmax*log(b_sigmax)- lgamma(a_sigmax)
) 
tempo_1e=(
lgamma(a_sigmae+0.5)-log(sqrt(2*pi*(1+tau_e)))-a_sigmae*log(b_sigmae)- lgamma(a_sigmae)
) 
tempo_1u=(
lgamma(a_sigmau+0.5)-log(sqrt(2*pi*(1+tau_u)))-a_sigmau*log(b_sigmau)- lgamma(a_sigmau)
)
###########
storage.mode(w)<-"double"
storage.mode(z)<-"double"
store_alpha_e=as.double(rep(0, nmcmc)); 
store_alpha_u=as.double(rep(0, nmcmc));
store_alpha_x=as.double(rep(0, nmcmc));
store_b1=matrix(0, ncol=p, nrow=nmcmc)
storage.mode(store_b1)<-"double"
store_b2=as.double(rep(0, nmcmc)); 
store_gamma1=matrix(0, ncol=p, nrow=nmcmc) 
storage.mode(store_gamma1)<-"double";
store_k_e=as.integer(rep(0, nmcmc));
store_k_u=as.integer(rep(0, nmcmc)); 
store_k_x=as.integer(rep(0, nmcmc));
store_bf=as.double(rep(0, nmcmc));
mu_nplus1_epsilon=as.double(rep(0, nmcmc));
mu_nplus1_u=matrix(0, nrow=nmcmc, ncol=m);
mu_nplus1_x=as.double(rep(0, nmcmc));
storage.mode(mu_nplus1_u)<-"double"
sigma2_nplus1_epsilon=as.double(rep(0, nmcmc));
sigma2_nplus1_u =matrix(0, nrow=nmcmc, ncol=m);
storage.mode(sigma2_nplus1_u)<-"double"
sigma2_nplus1_x=as.double(rep(0, nmcmc));
##############
out2=lm(wbar~z);
sigma2_gamma1=1*as.numeric(diag(summary(out2)$cov.unscaled)[-1])
mu_gamma1=as.numeric(out2$coef)[-1]
##############
mu_beta1=f$coef[2:(p+1)]
lambda= var(wbar)/(var(wbar)-mean(apply(w, 1, var))/m) 
mu_beta2=f$coef[p+2]#*lambda
if(!is.null(mean.beta)) {mu_beta1=mean.beta[1:p]; ; 
mu_beta2=mean.beta[(p+1)]}
sigma2_beta1=apply(cbind( 40*apply(bootest[, 2:(p+1)], 2, var), rep(5, p)), 1, min)
sigma2_beta2=min(40*var(bootest[, p+2]), 5)
if(!is.null(sigma2.beta)){sigma2_beta1=sigma2.beta[1:p]; 
sigma2_beta2=sigma2.beta[(p+1)]}
#
#
capn=min(n, as.integer(-2*log(1e-12/(4*n))+1))
capne=capn
capnu=capn
capnx=capn
#
a_sigmae=1
a_sigmau=1
a_sigmax=1
mean_e=0
mean_u=0
mean_x=0

 out=.Fortran("nonparaBayes", 
  as.double(a_alpha), as.double(a_sigmae), as.double(a_sigmau), 
  as.double(a_sigmax), as.double(b_alpha), as.integer(capne), 
  as.integer(capnu), as.integer(capnx), as.double(delta), 
  g_e=as.double(1), g_u=as.double(1), g_x=as.double(1), 
  h_e=as.double(1), h_u=as.double(1), h_x=as.double(1),
  initialbeta=as.double(newf$coef[-1]), initialmue=as.double(newf$coef[1]),
  initialsigma2e=as.double((newf$stats[5])^2), inputseed1=as.integer(inputseed),
  inputvarx=as.double(inputvarx), m=as.integer(m), as.double(mean_e),
  as.double(mean_u), as.double(mean_x), mu_beta1=as.double(mu_beta1),
  mu_beta2=as.double(mu_beta2), mu_gamma1=as.double(mu_gamma1), as.integer(n), 
  newmax=as.double(newmax), nmcmc=as.integer(nmcmc), ntm=as.integer(ntm),
  p=as.integer(p), pplus1=as.integer(p+1), sigma2_beta1=as.double(sigma2_beta1),
  sigma2_beta2=as.double(sigma2_beta2), sigma2_gamma1=as.double(sigma2_gamma1),
  output7=store_alpha_e, output8=store_alpha_u,
  output9=store_alpha_x,output10=store_b1, output11=store_b2, 
  output13=store_gamma1,  v=as.double(v), w, as.double(xhat), 
   z, PACKAGE="smmrbayes")
#
beta.sample=cbind(out$output10[-c(1:nburn), ], out$output11[-c(1:nburn)])
post.mean=apply(beta.sample[seq(1, nmc, nthin), ], 2, mean)
post.median=apply(beta.sample[seq(1, nmc, nthin), ], 2, median)
cred95.int=t(apply(beta.sample, 2, quantile, prob=c(0.025, 0.975)))
out=list()

Naive<-cbind(Est=as.numeric(store.f), SE=as.numeric(store.f.sd))
rownames(Naive)<-c( rep("covariate", p), "x")

Reg.calib=cbind(Est=as.numeric(newf$coef[-1]), SE=as.numeric(apply(bootest, 2, sd)[-1]))
rownames(Reg.calib)<-c( rep("covariate", p), "x")

Semi.Bayes=cbind(Posterior.mean=as.numeric(post.mean), Posterior.median=as.numeric(post.median), 
Credible.interval=as.matrix(cred95.int))
rownames(Semi.Bayes)<-c( rep("covariate", p), "x")

  out$naive <- Naive
  out$reg.calib <- Reg.calib
  out$semi.Bayes <- Semi.Bayes
} else {
#
#
#
#
#
#
#
#
#
if(min(n1, n2, n3)!= max(n1, n2, n3)) stop('Dimension mismatch')
if(is.na(sum(time)+sum(status)+sum(w)))  stop('There is a missing value')
#
#
# Naive method 
wbar=apply(w, 1, mean)
wbar=wbar-mean(wbar)
f <- bj(Surv(time,status) ~ wbar, link="log", control=list(iter.max=500))
store.f=f$coef[-1]
store.f.sd=sqrt(diag(f$var))[-1]
#
# Regression calibration 
w=as.matrix(w)
m=ncol(w)
sum1=0
for( i in 1:(m-1)){
  for( j in (i+1):m){
   sum1=sum1+sum((w[, i]-w[, j])^2)}}
   sigma2.w.x=sum1/(m*choose(m, 2)*2*n)
#
wbar=apply(w, 1, mean)
wbar=wbar-mean(wbar)
fout=lm(wbar~1)
sigma2.x.z=sum((wbar- fout$coef)^2)/(n-1)-sigma2.w.x
xhat=(wbar/sigma2.w.x+  fout$coef/sigma2.x.z)/(1/sigma2.w.x+1/sigma2.x.z)
newf <- bj(Surv(time,status) ~ xhat, link="log", control=list(iter.max=500))
inputvarx=1/(1/sigma2.w.x+1/sigma2.x.z)
#####
##### Standard error calculation bootstrap method 
#####
bootest=NULL;
orgtime=time; orgstatus=status; orgw=w; 
for( it in 1:capb){
set.seed(it)
index=sample((1:n), replace=T)
time=orgtime[index]; 
status=orgstatus[index]
w=orgw[index, ]
###
sum1=0
for( i in 1:(m-1)){
  for( j in (i+1):m){
   sum1=sum1+sum((w[, i]-w[, j])^2)}}
   sigma2.w.x=sum1/(m*choose(m, 2)*2*n)
#
wbar=apply(w, 1, mean)
wbar=wbar-mean(wbar)
fout=lm(wbar~1)
sigma2.x.z=sum((wbar- fout$coef)^2)/(n-1)-sigma2.w.x
xhat=(wbar/sigma2.w.x+  fout$coef/sigma2.x.z)/(1/sigma2.w.x+1/sigma2.x.z)
bootf <- bj(Surv(time,status) ~ xhat, link="log", control=list(iter.max=500))
###
bootest=rbind(bootest, bootf$coef)
}
# 
# Proposed Bayesian method 
##
v=orgtime; delta=orgstatus; w=orgw; 

ntm=n*m
nburn=1000;
if(!is.null(numb.burn)) nburn=numb.burn
nthin=10;
if(!is.null(numb.thin)) nthin=numb.thin
nmc=nmcmc-nburn
if(nmc<2*nthin) stop('nmcmc is very  small')
w=w-mean(as.numeric(w))
wbar = apply(w, 1, mean)
########
inputseed=100000*runif(1)  
###
tau_e = 2 
tau_u= 2.
tau_x = 2.0  
#### determination of prior parameters 
#### for x
newa=var(wbar)-min(apply(w, 1, var))/m;
newb=newa
a_sigmax=newa^2/newb+2;
b_sigmax= 1/(newa*(a_sigmax-1) )
### for u
newa=median(apply(w, 1, var))
newb=newa
a_sigmau=newa^2/newb+2;
b_sigmau= 1/(newa*(a_sigmau-1) )	
#### for e
newa=var(log(v)[delta==1])
newb=newa
a_sigmae=1*newa^2/newb+2;
b_sigmae=1/ (newa*(a_sigmae-1) )
###########
newmax=20*var(wbar)
###########
a_alpha=1;
b_alpha=1;
tempo_1x=(
lgamma(a_sigmax+0.5)-log(sqrt(2*pi*(1+tau_x)))-a_sigmax*log(b_sigmax)- lgamma(a_sigmax)
) 
tempo_1e=(
lgamma(a_sigmae+0.5)-log(sqrt(2*pi*(1+tau_e)))-a_sigmae*log(b_sigmae)- lgamma(a_sigmae)
) 
tempo_1u=(
lgamma(a_sigmau+0.5)-log(sqrt(2*pi*(1+tau_u)))-a_sigmau*log(b_sigmau)- lgamma(a_sigmau)
)
###########
storage.mode(w)<-"double"
store_alpha_e=as.double(rep(0, nmcmc)); 
store_alpha_u=as.double(rep(0, nmcmc));
store_alpha_x=as.double(rep(0, nmcmc));
store_b2=as.double(rep(0, nmcmc)); 
store_k_e=as.integer(rep(0, nmcmc));
store_k_u=as.integer(rep(0, nmcmc)); 
store_k_x=as.integer(rep(0, nmcmc));
store_bf=as.double(rep(0, nmcmc));
mu_nplus1_epsilon=as.double(rep(0, nmcmc));
mu_nplus1_u=matrix(0, nrow=nmcmc, ncol=m);
mu_nplus1_x=as.double(rep(0, nmcmc));
storage.mode(mu_nplus1_u)<-"double"
sigma2_nplus1_epsilon=as.double(rep(0, nmcmc));
sigma2_nplus1_u =matrix(0, nrow=nmcmc, ncol=m);
storage.mode(sigma2_nplus1_u)<-"double"
sigma2_nplus1_x=as.double(rep(0, nmcmc));
##############
##############
mu_beta2=f$coef[2]
if(!is.null(mean.beta)) {mu_beta2=mean.beta}
sigma2_beta2=min(40*var(bootest[, 2]), 5)
if(!is.null(sigma2.beta)){sigma2_beta2=sigma2.beta}
#
#
capn=min(n, 2*as.integer(-log(1e-12/(4*n))+1))
capne=capn
capnu=capn
capnx=capn
#
a_sigmae=1
a_sigmau=1
a_sigmax=1
mean_e=0
mean_u=0
mean_x=0

 out=.Fortran("nonparaBayesnocovar", 
  as.double(a_alpha), as.double(a_sigmae), as.double(a_sigmau), 
  as.double(a_sigmax), as.double(b_alpha), as.integer(capne), 
  as.integer(capnu), as.integer(capnx), as.double(delta), 
  g_e=as.double(1), g_u=as.double(1), g_x=as.double(1), 
  h_e=as.double(1), h_u=as.double(1), h_x=as.double(1),
  initialbeta=as.double(newf$coef[-1]), initialmue=as.double(newf$coef[1]),
  initialsigma2e=as.double((newf$stats[5])^2), inputseed1=as.integer(inputseed),
  inputvarx=as.double(inputvarx), m=as.integer(m), as.double(mean_e),
  as.double(mean_u), as.double(mean_x), mu_beta2=as.double(mu_beta2), 
  as.integer(n), 
  newmax=as.double(newmax), nmcmc=as.integer(nmcmc), ntm=as.integer(ntm),
  sigma2_beta2=as.double(sigma2_beta2), output7=store_alpha_e,
  output8=store_alpha_u, output9=store_alpha_x, output11=store_b2, 
  v=as.double(v), w, as.double(xhat), PACKAGE="smmrbayes")
#
beta.sample=out$output11[-c(1:nburn)]
post.mean=mean(beta.sample[seq(1, nmc, nthin)])
post.median=median(beta.sample[seq(1, nmc, nthin)])
cred95.int=quantile(beta.sample, prob=c(0.025, 0.975))

out=list()

Naive<-cbind(Est=as.numeric(store.f), SE=as.numeric(store.f.sd))
rownames(Naive)<-"x"

Reg.calib=cbind(Est=as.numeric(newf$coef[-1]), SE=as.numeric(apply(bootest, 2, sd)[-1]))
rownames(Reg.calib)<-"x"

Semi.Bayes=cbind(Posterior.mean=as.numeric(post.mean), Posterior.median=as.numeric(post.median), 
Credible.interval=t(cred95.int))
rownames(Semi.Bayes)<-"x"

  out$naive <- Naive
  out$reg.calib <- Reg.calib
  out$semi.Bayes <- Semi.Bayes
}
return(out)
}

#.First.lib<-function(lib, pkg){
#library.dynam("smmrbayes", pkg, lib)
#}



